// Lưu trữ JSON đơn giản, ghi nguyên tử (ghi file tạm rồi rename) để không hỏng dữ liệu khi tắt đột ngột.
import fs from 'node:fs';
import path from 'node:path';

export class Store {
  constructor(file) {
    this.file = file;
    this.data = { users: {}, sessions: {} };
    this.queue = Promise.resolve();
    if (fs.existsSync(file)) {
      this.data = JSON.parse(fs.readFileSync(file, 'utf8'));
      this.data.users ??= {};
      this.data.sessions ??= {};
    } else {
      fs.mkdirSync(path.dirname(file), { recursive: true });
    }
  }

  // Ghi tuần tự để các request đồng thời không chồng lên nhau.
  save() {
    const snapshot = JSON.stringify(this.data, null, 2);
    this.queue = this.queue.then(async () => {
      const tmp = `${this.file}.${process.pid}.tmp`;
      await fs.promises.writeFile(tmp, snapshot, 'utf8');
      await fs.promises.rename(tmp, this.file);
    });
    return this.queue;
  }
}
