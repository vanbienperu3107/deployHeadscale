import express from 'express';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Store } from './store.js';
import {
  validateCharacterName, validateUsername, validatePassword,
  validateGender, validateOutfit,
} from '../shared/validation.js';
import { getTemple, isQuestStep, emptyProgress, questComplete } from '../shared/temples.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SESSION_DAYS = 7;
const COOKIE = 'sid';

function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return { salt, hash };
}

function verifyPassword(password, salt, hash) {
  const test = crypto.scryptSync(password, salt, 64);
  const real = Buffer.from(hash, 'hex');
  return real.length === test.length && crypto.timingSafeEqual(real, test);
}

function parseCookies(header = '') {
  const out = {};
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

export function createApp({ dataFile = process.env.DATA_FILE || path.join(ROOT, 'data', 'db.json') } = {}) {
  const store = new Store(dataFile);
  const app = express();
  app.disable('x-powered-by');
  app.use(express.json({ limit: '10kb' }));

  // Dùng cho Docker HEALTHCHECK / reverse proxy.
  app.get('/healthz', (_req, res) => res.json({ ok: true }));

  // Xác định user từ cookie phiên.
  app.use((req, _res, next) => {
    const sid = parseCookies(req.headers.cookie)[COOKIE];
    const s = sid && store.data.sessions[sid];
    if (s && s.expires > Date.now()) req.user = store.data.users[s.username];
    else if (s) delete store.data.sessions[sid];
    req.sid = sid;
    next();
  });

  const startSession = (res, username) => {
    const sid = crypto.randomBytes(32).toString('hex');
    store.data.sessions[sid] = { username, expires: Date.now() + SESSION_DAYS * 864e5 };
    res.cookie(COOKIE, sid, {
      httpOnly: true, sameSite: 'strict', maxAge: SESSION_DAYS * 864e5, path: '/',
    });
  };

  const publicUser = (u) => ({ username: u.username, character: u.character ?? null });

  app.post('/api/register', async (req, res) => {
    const { username, password } = req.body ?? {};
    const vu = validateUsername(username);
    if (!vu.ok) return res.status(400).json({ error: vu.error });
    const vp = validatePassword(password);
    if (!vp.ok) return res.status(400).json({ error: vp.error });
    if (store.data.users[vu.username]) return res.status(409).json({ error: 'Tên đăng nhập đã tồn tại.' });

    store.data.users[vu.username] = {
      username: vu.username, ...hashPassword(password), createdAt: new Date().toISOString(), character: null,
    };
    startSession(res, vu.username);
    await store.save();
    res.status(201).json(publicUser(store.data.users[vu.username]));
  });

  app.post('/api/login', async (req, res) => {
    const { username, password } = req.body ?? {};
    const u = typeof username === 'string' && store.data.users[username.toLowerCase()];
    if (!u || typeof password !== 'string' || !verifyPassword(password, u.salt, u.hash)) {
      return res.status(401).json({ error: 'Sai tên đăng nhập hoặc mật khẩu.' });
    }
    startSession(res, u.username);
    await store.save();
    res.json(publicUser(u));
  });

  app.post('/api/logout', async (req, res) => {
    if (req.sid) delete store.data.sessions[req.sid];
    res.clearCookie(COOKIE, { path: '/' });
    await store.save();
    res.json({ ok: true });
  });

  app.get('/api/me', (req, res) => {
    if (!req.user) return res.status(401).json({ error: 'Chưa đăng nhập.' });
    res.json(publicUser(req.user));
  });

  app.post('/api/character', async (req, res) => {
    if (!req.user) return res.status(401).json({ error: 'Chưa đăng nhập.' });
    if (req.user.character) return res.status(409).json({ error: 'Bạn đã tạo nhân vật rồi.' });
    const { name, gender, outfit = 'nau' } = req.body ?? {};
    const vn = validateCharacterName(name);
    if (!vn.ok) return res.status(400).json({ error: vn.error });
    const vg = validateGender(gender);
    if (!vg.ok) return res.status(400).json({ error: vg.error });
    const vo = validateOutfit(outfit);
    if (!vo.ok) return res.status(400).json({ error: vo.error });

    const key = vn.name.toLocaleLowerCase('vi');
    const taken = Object.values(store.data.users).some(
      (u) => u.character && u.character.name.toLocaleLowerCase('vi') === key,
    );
    if (taken) return res.status(409).json({ error: 'Tên nhân vật đã có người dùng.' });

    req.user.character = { name: vn.name, gender, outfit, createdAt: new Date().toISOString() };
    await store.save();
    res.status(201).json(publicUser(req.user));
  });

  // ----- Đi chùa: tiến độ, nhiệm vụ, chứng nhận -----
  const needCharacter = (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Chưa đăng nhập.' });
    if (!req.user.character) return res.status(403).json({ error: 'Bạn cần tạo nhân vật trước.' });
    const temple = getTemple(req.params.id);
    if (!temple) return res.status(404).json({ error: 'Không tìm thấy chùa.' });
    req.temple = temple;
    req.user.visits ??= {};
    req.progress = req.user.visits[temple.id] ??= emptyProgress();
    next();
  };
  const progressView = (req) => ({
    ...req.progress,
    complete: questComplete(req.temple, req.progress),
  });

  app.get('/api/temples/:id/progress', needCharacter, (req, res) => {
    res.json(progressView(req));
  });

  app.post('/api/temples/:id/quest/accept', needCharacter, async (req, res) => {
    req.progress.accepted ??= new Date().toISOString();
    await store.save();
    res.json(progressView(req));
  });

  app.post('/api/temples/:id/step', needCharacter, async (req, res) => {
    const step = req.body?.step;
    // Thắp hương chỉ được ghi qua /incense để đếm số lần.
    if (!isQuestStep(req.temple, step) || step === 'offer-incense') {
      return res.status(400).json({ error: 'Bước nhiệm vụ không hợp lệ.' });
    }
    req.progress.steps[step] ??= new Date().toISOString();
    await store.save();
    res.json(progressView(req));
  });

  app.post('/api/temples/:id/incense', needCharacter, async (req, res) => {
    req.progress.incense = (req.progress.incense ?? 0) + 1;
    req.progress.steps['offer-incense'] ??= new Date().toISOString();
    await store.save();
    res.json(progressView(req));
  });

  app.post('/api/temples/:id/certificate', needCharacter, async (req, res) => {
    if (!questComplete(req.temple, req.progress)) {
      return res.status(409).json({ error: 'Bạn chưa hoàn thành nhiệm vụ của chùa.' });
    }
    req.progress.certificate ??= {
      code: `${req.temple.id.toUpperCase()}-${crypto.randomBytes(4).toString('hex').toUpperCase()}`,
      characterName: req.user.character.name,
      templeName: req.temple.name,
      issuedAt: new Date().toISOString(),
    };
    await store.save();
    res.json(progressView(req));
  });

  app.use('/shared', express.static(path.join(ROOT, 'shared')));
  app.use('/vendor/three', express.static(path.join(ROOT, 'node_modules', 'three')));
  app.use(express.static(path.join(ROOT, 'public')));

  app.locals.store = store;
  return app;
}
