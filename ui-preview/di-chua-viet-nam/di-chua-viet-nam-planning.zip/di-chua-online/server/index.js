import { createApp } from './app.js';

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || '0.0.0.0';

const server = createApp().listen(PORT, HOST, () => {
  console.log(`Đi chùa Việt Nam đang chạy: http://localhost:${PORT}`);
});

// Tắt êm khi `docker stop` gửi SIGTERM: ngừng nhận kết nối mới, chờ request đang chạy.
for (const sig of ['SIGTERM', 'SIGINT']) {
  process.on(sig, () => {
    console.log(`Nhận ${sig}, đang dừng server...`);
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 5000).unref();
  });
}
