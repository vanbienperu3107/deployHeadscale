import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createApp } from '../server/app.js';

async function start(dataFile) {
  const app = createApp({ dataFile });
  const server = await new Promise((r) => { const s = app.listen(0, () => r(s)); });
  const base = `http://127.0.0.1:${server.address().port}`;
  return { app, server, base };
}

function client(base) {
  let cookie = '';
  return async (p, body) => {
    const res = await fetch(base + p, {
      method: body ? 'POST' : 'GET',
      headers: { 'Content-Type': 'application/json', ...(cookie && { cookie }) },
      body: body ? JSON.stringify(body) : undefined,
    });
    const sc = res.headers.get('set-cookie');
    if (sc) cookie = sc.split(';')[0];
    return { status: res.status, body: await res.json().catch(() => null), headers: res.headers };
  };
}

const tmpFile = () => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'dichua-')), 'db.json');

test('API: luồng đăng ký -> tạo nhân vật -> đăng nhập lại', async (t) => {
  const file = tmpFile();
  const { server, base } = await start(file);
  t.after(() => server.close());
  const a = client(base);

  // TC-A1 chưa đăng nhập
  assert.equal((await a('/api/me')).status, 401);
  assert.equal((await a('/api/character', { name: 'Tâm', gender: 'nam' })).status, 401);

  // TC-A2 đăng ký, cookie HttpOnly
  const reg = await a('/api/register', { username: 'Phattu01', password: 'matkhau1' });
  assert.equal(reg.status, 201);
  assert.match(reg.headers.get('set-cookie'), /HttpOnly/i);
  assert.equal(reg.body.character, null);
  assert.equal(reg.body.hash, undefined);

  // TC-A3 trùng username (không phân biệt hoa thường)
  assert.equal((await client(base)('/api/register', { username: 'phattu01', password: 'xxxxxx' })).status, 409);

  // TC-C1 tên quá 25 ký tự / giới tính sai / màu sai
  assert.equal((await a('/api/character', { name: 'Ạ'.repeat(26), gender: 'nam' })).status, 400);
  assert.equal((await a('/api/character', { name: 'Minh Tâm', gender: 'x' })).status, 400);
  assert.equal((await a('/api/character', { name: 'Minh Tâm', gender: 'nam', outfit: 'toString' })).status, 400);

  // TC-C2 tạo thành công
  const c = await a('/api/character', { name: '  Nguyễn Thị Hằng ', gender: 'nu', outfit: 'lam' });
  assert.equal(c.status, 201);
  assert.deepEqual(
    { name: c.body.character.name, gender: c.body.character.gender, outfit: c.body.character.outfit },
    { name: 'Nguyễn Thị Hằng', gender: 'nu', outfit: 'lam' },
  );

  // TC-C3 không tạo lần 2
  assert.equal((await a('/api/character', { name: 'Khác', gender: 'nam' })).status, 409);

  // TC-C4 tên nhân vật trùng (không phân biệt hoa thường) bị chặn
  const b = client(base);
  await b('/api/register', { username: 'phattu02', password: 'matkhau2' });
  assert.equal((await b('/api/character', { name: 'NGUYỄN THỊ HẰNG', gender: 'nu' })).status, 409);

  // TC-A4 sai mật khẩu, đăng xuất, đăng nhập lại
  assert.equal((await client(base)('/api/login', { username: 'phattu01', password: 'sai' })).status, 401);
  assert.equal((await a('/api/logout', {})).status, 200);
  assert.equal((await a('/api/me')).status, 401);
  const login = await a('/api/login', { username: 'PHATTU01', password: 'matkhau1' });
  assert.equal(login.status, 200);
  assert.equal(login.body.character.name, 'Nguyễn Thị Hằng');
});

test('API: dữ liệu còn sau khi khởi động lại server (TC-R1)', async () => {
  const file = tmpFile();
  let s = await start(file);
  const a = client(s.base);
  await a('/api/register', { username: 'luutru', password: 'matkhau1' });
  await a('/api/character', { name: 'Thiện Tâm', gender: 'nam' });
  await s.app.locals.store.queue;
  s.server.close();

  s = await start(file);
  const login = await client(s.base)('/api/login', { username: 'luutru', password: 'matkhau1' });
  assert.equal(login.body.character.name, 'Thiện Tâm');
  assert.ok(!fs.readFileSync(file, 'utf8').includes('matkhau1'), 'không lưu mật khẩu thô');
  s.server.close();
});

test('API: tạo nhân vật đồng thời cùng tên chỉ 1 thành công (TC-X1)', async (t) => {
  const { server, base } = await start(tmpFile());
  t.after(() => server.close());
  const cs = [];
  for (let i = 0; i < 5; i++) {
    const c = client(base);
    await c('/api/register', { username: `dongthoi${i}`, password: 'matkhau1' });
    cs.push(c);
  }
  const rs = await Promise.all(cs.map((c) => c('/api/character', { name: 'Tịnh Tâm', gender: 'nam' })));
  assert.equal(rs.filter((r) => r.status === 201).length, 1);
});
