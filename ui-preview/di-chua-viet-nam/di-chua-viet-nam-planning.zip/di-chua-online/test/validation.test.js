import test from 'node:test';
import assert from 'node:assert/strict';
import { validateCharacterName, validateUsername, validateGender } from '../shared/validation.js';

test('TC-N1 chấp nhận tên tiếng Việt có dấu', () => {
  for (const n of ['Nguyễn Thị Hằng', 'Đặng Quốc Việt', 'Minh Tâm', 'Ưng Hoàng Phúc', 'Lê Ỷ Lan 2']) {
    assert.equal(validateCharacterName(n).ok, true, n);
  }
});

test('TC-N2 đúng 25 ký tự được, 26 bị từ chối', () => {
  const n25 = 'Ạ'.repeat(25);
  assert.equal(validateCharacterName(n25).ok, true);
  assert.equal(validateCharacterName('Ạ'.repeat(26)).ok, false);
});

test('TC-N3 dấu tổ hợp (NFD) được chuẩn hoá NFC và đếm đúng', () => {
  const nfd = 'Ạ'.repeat(25).normalize('NFD'); // 50 code point
  const r = validateCharacterName(nfd);
  assert.equal(r.ok, true);
  assert.equal(r.name, 'Ạ'.repeat(25));
});

test('TC-N4 rỗng, quá ngắn, ký tự lạ, HTML bị từ chối', () => {
  for (const n of ['', '   ', 'A', '<script>', 'Tâm😀', 'a_b', null, 123, 'Tâm\u200b']) {
    assert.equal(validateCharacterName(n).ok, false, String(n));
  }
});

test('TC-N5 gộp khoảng trắng, cắt hai đầu', () => {
  assert.equal(validateCharacterName('  Minh    Tâm  ').name, 'Minh Tâm');
});

test('TC-U1 username và giới tính', () => {
  assert.equal(validateUsername('user_01').ok, true);
  assert.equal(validateUsername('ab').ok, false);
  assert.equal(validateUsername('tâm').ok, false);
  assert.equal(validateGender('nam').ok, true);
  assert.equal(validateGender('nu').ok, true);
  assert.equal(validateGender('khac').ok, false);
});
