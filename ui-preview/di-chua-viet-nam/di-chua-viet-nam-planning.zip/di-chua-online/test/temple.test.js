import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createApp } from '../server/app.js';
import { TEMPLES, getTemple, questComplete, emptyProgress } from '../shared/temples.js';

async function start(dataFile) {
  const app = createApp({ dataFile });
  const server = await new Promise((r) => { const s = app.listen(0, () => r(s)); });
  return { app, server, base: `http://127.0.0.1:${server.address().port}` };
}
function client(base) {
  let cookie = '';
  return async (p, body) => {
    const res = await fetch(base + p, {
      method: body ? 'POST' : 'GET',
      headers: { 'Content-Type': 'application/json', ...(cookie && { cookie }) },
      body: body ? JSON.stringify(body) : undefined,
    });
    const sc = res.headers.get('set-cookie');
    if (sc) cookie = sc.split(';')[0];
    return { status: res.status, body: await res.json().catch(() => null) };
  };
}
const tmpFile = () => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'dichua-')), 'db.json');
const P = '/api/temples/tran-quoc';

test('TQ-D1 dữ liệu chùa Trấn Quốc đúng yêu cầu', () => {
  assert.equal(TEMPLES[0].id, 'tran-quoc');
  const t = getTemple('tran-quoc');
  assert.equal(t.gateSign, 'Lối cổng vào chùa Trấn Quốc');
  assert.match(t.history.join(' '), /năm 541 thời Tiền Lý/);
  assert.match(t.history.join(' '), /Trấn Bắc/);
  for (const z of ['bai-duong', 'vuon-thap', 'bao-thap']) assert.ok(t.zones[z].name);
  assert.equal(questComplete(t, emptyProgress()), false);
});

test('TQ-A1 cần đăng nhập và có nhân vật', async (t) => {
  const { server, base } = await start(tmpFile());
  t.after(() => server.close());
  const a = client(base);
  assert.equal((await a(`${P}/progress`)).status, 401);
  await a('/api/register', { username: 'chua01', password: 'matkhau1' });
  assert.equal((await a(`${P}/progress`)).status, 403);
  await a('/api/character', { name: 'Minh Tâm', gender: 'nam' });
  assert.equal((await a('/api/temples/khong-co/progress')).status, 404);
  assert.equal((await a(`${P}/progress`)).status, 200);
});

test('TQ-Q1 nhiệm vụ đầy đủ -> chứng nhận; chặn cấp sớm và bước sai', async (t) => {
  const file = tmpFile();
  let s = await start(file);
  const a = client(s.base);
  await a('/api/register', { username: 'chua02', password: 'matkhau1' });
  await a('/api/character', { name: 'Diệu Hạnh', gender: 'nu', outfit: 'lam' });

  assert.equal((await a(`${P}/certificate`, {})).status, 409);
  assert.equal((await a(`${P}/step`, { step: 'bay-ba' })).status, 400);
  assert.equal((await a(`${P}/step`, { step: 'offer-incense' })).status, 400);
  assert.equal((await a(`${P}/step`, { step: '__proto__' })).status, 400);

  // Làm hết bước nhưng chưa nhận nhiệm vụ từ NPC -> chưa hoàn thành
  for (const step of ['read-history', 'visit-vuon-thap', 'visit-bao-thap', 'visit-bo-de']) {
    assert.equal((await a(`${P}/step`, { step })).status, 200);
  }
  let r = await a(`${P}/incense`, {});
  assert.equal(r.body.incense, 1);
  r = await a(`${P}/incense`, {}); // vái tiếp lần 2
  assert.equal(r.body.incense, 2);
  assert.equal(r.body.complete, false);
  assert.equal((await a(`${P}/certificate`, {})).status, 409);

  r = await a(`${P}/quest/accept`, {});
  assert.equal(r.body.complete, true);
  const c1 = await a(`${P}/certificate`, {});
  assert.equal(c1.status, 200);
  assert.equal(c1.body.certificate.characterName, 'Diệu Hạnh');
  assert.match(c1.body.certificate.code, /^TRAN-QUOC-[0-9A-F]{8}$/);
  // Cấp lại trả về cùng mã (idempotent)
  const c2 = await a(`${P}/certificate`, {});
  assert.equal(c2.body.certificate.code, c1.body.certificate.code);
  await s.app.locals.store.queue;
  s.server.close();

  // Khởi động lại vẫn còn
  s = await start(file);
  const b = client(s.base);
  await b('/api/login', { username: 'chua02', password: 'matkhau1' });
  r = await b(`${P}/progress`);
  assert.equal(r.body.certificate.code, c1.body.certificate.code);
  assert.equal(r.body.incense, 2);
  s.server.close();
});
