// Quy tắc kiểm tra dùng chung cho server (Node) và trình duyệt.

export const NAME_MAX = 25;
export const NAME_MIN = 2;
export const GENDERS = ['nam', 'nu'];
export const OUTFIT_COLORS = {
  nau: { label: 'Nâu', hex: '#9a6248' },
  lam: { label: 'Lam', hex: '#4a6b8a' },
  xam: { label: 'Xám', hex: '#8a8780' },
  trang: { label: 'Trắng', hex: '#e9e4d8' },
};

// Chỉ chữ cái hệ Latin (bao gồm toàn bộ chữ tiếng Việt có dấu), chữ số và khoảng trắng.
const NAME_RE = /^[\p{Script=Latin}0-9 ]+$/u;
const USERNAME_RE = /^[a-zA-Z0-9_]{3,20}$/;

export function normalizeName(raw) {
  if (typeof raw !== 'string') return '';
  // NFC để "ế" gõ kiểu tổ hợp (e + dấu) chỉ tính là 1 ký tự.
  return raw.normalize('NFC').replace(/\s+/g, ' ').trim();
}

export function nameLength(name) {
  return [...name].length;
}

export function validateCharacterName(raw) {
  const name = normalizeName(raw);
  if (!name) return { ok: false, error: 'Vui lòng nhập tên nhân vật.' };
  const len = nameLength(name);
  if (len < NAME_MIN) return { ok: false, error: `Tên phải có ít nhất ${NAME_MIN} ký tự.` };
  if (len > NAME_MAX) return { ok: false, error: `Tên không được quá ${NAME_MAX} ký tự (hiện ${len}).` };
  if (!NAME_RE.test(name)) {
    return { ok: false, error: 'Tên chỉ gồm chữ cái (có dấu tiếng Việt), chữ số và khoảng trắng.' };
  }
  return { ok: true, name };
}

export function validateUsername(raw) {
  if (typeof raw !== 'string' || !USERNAME_RE.test(raw)) {
    return { ok: false, error: 'Tên đăng nhập 3–20 ký tự: chữ không dấu, số hoặc dấu gạch dưới.' };
  }
  return { ok: true, username: raw.toLowerCase() };
}

export function validatePassword(raw) {
  if (typeof raw !== 'string' || raw.length < 6 || raw.length > 100) {
    return { ok: false, error: 'Mật khẩu phải từ 6 đến 100 ký tự.' };
  }
  return { ok: true };
}

export function validateGender(g) {
  return GENDERS.includes(g) ? { ok: true } : { ok: false, error: 'Vui lòng chọn Nam hoặc Nữ.' };
}

export function validateOutfit(c) {
  return Object.hasOwn(OUTFIT_COLORS, c) ? { ok: true } : { ok: false, error: 'Màu áo không hợp lệ.' };
}
