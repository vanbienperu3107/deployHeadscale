// Dữ liệu các chùa + nhiệm vụ. Dùng chung cho server (kiểm tra hợp lệ) và trình duyệt (hiển thị).

export const APP_NAME = 'Đi chùa Việt Nam';

export const TEMPLES = [
  {
    id: 'tran-quoc',
    name: 'Chùa Trấn Quốc',
    location: 'Đường Thanh Niên, quận Tây Hồ, Hà Nội',
    short: 'Ngôi cổ tự hơn 1.400 năm tuổi trên bán đảo nhỏ phía đông Hồ Tây.',
    gateSign: 'Lối cổng vào chùa Trấn Quốc',
    historyTitle: 'Giới thiệu lịch sử chùa Trấn Quốc',
    history: [
      'Theo sử sách, các tài liệu ghi lại, Trấn Quốc tự được xây dựng năm 541 thời Tiền Lý và có tên gọi ban đầu là chùa Khai Quốc. Thuở ban đầu, chùa nằm tại bãi đất làng Yên Hoà là làng Yên Phụ ngày nay.',
      'Đến năm 1440, vua Lê Thái Tông đã đổi tên chùa thành chùa An Quốc với mong muốn đất nước được bình an, lâu bền. Năm 1615, dưới triều vua Lê Kính Tông, chùa được dời sang khu vực đê Yên Phụ, xây dựng trên nền cũ là điện Hàn Nguyên của nhà Trần và cung Thuý Hoa của nhà Lý. Năm 1639, chúa Trịnh đã cho xây dựng hành lang hai bên tả hữu và tu sửa lại cổng tam quan. Đến thời vua Lê Hy Tông, chùa được đổi tên một lần nữa thành chùa Trấn Quốc. Chùa được đúc chuông, đắp thêm tượng và tôn tạo lại vô cùng hoành tráng vào đầu đời nhà Nguyễn. Năm 1821, vua Minh Mạng đã ngự giá tới tham quan chùa và ban 20 lạng bạc để mở rộng và trùng tu chùa. Tới năm 1842, vua Thiệu Trị ban 200 quan tiền và 1 đồng vàng lớn đồng thời cũng đổi tên chùa thành chùa Trấn Bắc. Nhưng dân chúng từ xưa vẫn quen gọi chùa với cái tên Trấn Quốc, nhờ vậy mà cái tên này vẫn được giữ mãi đến ngày nay.',
    ],
    closingNote: 'Trải nghiệm đi chùa online không thể mô tả được hết, bạn nên đi chùa ở ngoài đời để trải nghiệm thật sự. Cảm ơn bạn.',
    zones: {
      'bai-duong': {
        name: 'Nhà Bái đường (Nhà Tiền đường)',
        desc: 'Nằm ở trung tâm, hướng về phía Tây, là nơi làm lễ chính. Phía trong là Chính điện, nơi tôn trí những pho tượng Phật bằng đồng. Phật tử vào đây thắp hương, vái Phật.',
        image: '/img/tran-quoc/bai-duong.svg',
      },
      'vuon-thap': {
        name: 'Khu Vườn tháp',
        desc: 'Vườn tháp cổ của chùa gồm nhiều ngôi tháp được dựng từ thời Vĩnh Hựu, Cảnh Hưng (thế kỷ 18). Đây là nơi tưởng niệm và lưu giữ xá lợi của các vị hòa thượng trụ trì chùa qua nhiều thời kỳ.',
      },
      'bao-thap': {
        name: 'Bảo tháp Lục độ đài sen',
        desc: 'Khởi công năm 1998, hoàn thành năm 2003. Tháp cao 11 tầng, mỗi tầng có 6 ô cửa hình vòm, mỗi ô đặt một pho tượng Phật A Di Đà; đỉnh tháp là đài sen. "Lục độ" là sáu pháp tu của Bồ Tát: bố thí, trì giới, nhẫn nhục, tinh tấn, thiền định và trí tuệ.',
      },
      'bo-de': {
        name: 'Cây Bồ đề',
        desc: 'Cây Bồ đề trong vườn chùa do Tổng thống Ấn Độ Rajendra Prasad tặng khi sang thăm Hà Nội năm 1959, được chiết từ cây Bồ đề nơi Đức Phật thành đạo. Bồ đề là biểu tượng của sự giác ngộ.',
      },
      'cong': {
        name: 'Cổng ra',
        desc: 'Lối trở ra cổng chùa.',
      },
    },
    npc: {
      name: 'Chú tiểu Minh An',
      greeting: 'A Di Đà Phật! Chào mừng thí chủ đến chùa Trấn Quốc. Tiểu tăng sẽ hướng dẫn thí chủ một vòng viếng chùa. Hoàn thành các việc sau, thí chủ sẽ nhận được Giấy chứng nhận đã đến chùa.',
      inProgress: 'Thí chủ còn vài việc chưa làm xong. Cứ thong thả, đi chùa quý ở tâm thành.',
      done: 'Thí chủ đã hoàn thành hành trình viếng chùa. Xin trao Giấy chứng nhận. Mong thí chủ có dịp đến chùa ở ngoài đời. A Di Đà Phật!',
    },
    quest: [
      { id: 'read-history', label: 'Đọc bảng giới thiệu lịch sử chùa ở cổng' },
      { id: 'offer-incense', label: 'Thắp hương và vái Phật trong nhà Bái đường' },
      { id: 'visit-vuon-thap', label: 'Thăm Khu Vườn tháp' },
      { id: 'visit-bao-thap', label: 'Thăm Bảo tháp Lục độ đài sen' },
      { id: 'visit-bo-de', label: 'Thăm cây Bồ đề' },
    ],
  },
];

export function getTemple(id) {
  return TEMPLES.find((t) => t.id === id) ?? null;
}

export function isQuestStep(temple, stepId) {
  return !!temple && temple.quest.some((q) => q.id === stepId);
}

export function emptyProgress() {
  return { accepted: null, steps: {}, incense: 0, certificate: null };
}

export function questComplete(temple, progress) {
  return !!progress?.accepted && temple.quest.every((q) => progress.steps?.[q.id]);
}
