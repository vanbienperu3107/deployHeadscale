// Dựng nhân vật 3D bằng Three.js (procedural, không cần file model ngoài).
// Trang phục Phật tử: áo cổ chữ V đứng, 5 nút thắt vải, tay lửng 3/4, áo qua hông, quần ống suông.
// Có khớp hông/gối/vai/khuỷu để đi bộ, chắp tay, quỳ và lạy.
import * as THREE from 'three';
import { OUTFIT_COLORS } from '/shared/validation.js';

const SKIN = 0xe8bf9c;
const HAIR = 0x1b1512;
const DEPTH = 0.62; // độ dẹt thân (sâu = ngang * DEPTH)
const Y = new THREE.Vector3(0, -1, 0);

function mat(color, rough = 0.85) {
  return new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: 0 });
}
function shade(hex, f) {
  return new THREE.Color(hex).multiplyScalar(f);
}

// Tư thế tay: hướng cánh tay trên và cẳng tay trong hệ toạ độ thân trên (x: phải, y: lên, z: trước).
const ARM_POSES = {
  clasp: { upper: [0.12, -1, 0.12], fore: [-0.75, -0.7, 0.55] }, // chắp nhẹ phía trước bụng
  down: { upper: [0.1, -1, 0.0], fore: [0.03, -1, 0.12] },     // buông tự nhiên khi đi
  pray: { upper: [0.15, -1, 0.35], fore: [-0.85, 0.5, 0.4] },   // chắp tay trước ngực
};

/**
 * @param {{gender?:'nam'|'nu', outfit?:string, monk?:boolean}} opts
 * Trả về Group có userData.pose (điều khiển tư thế) và userData.update(t, dt).
 */
export function createCharacter({ gender = 'nam', outfit = 'nau', monk = false } = {}) {
  const female = gender === 'nu';
  const clothHex = monk ? '#8a6a3c' : (OUTFIT_COLORS[outfit] ?? OUTFIT_COLORS.nau).hex;
  const cloth = mat(clothHex);
  const clothDark = mat(shade(clothHex, 0.72));
  const skin = mat(SKIN, 0.6);
  const hair = mat(HAIR, 0.5);

  const root = new THREE.Group();
  root.name = monk ? 'npc' : 'character';
  const model = new THREE.Group(); // dùng để hạ thấp khi quỳ
  root.add(model);
  const s = monk ? 0.88 : female ? 0.95 : 1;
  model.scale.setScalar(s);

  const shoulderW = female ? 0.2 : 0.235;
  const hipY = 0.92;
  const thighLen = 0.43;
  const shinLen = hipY - thighLen - 0.06;

  // ---------- Chân: hông -> đùi -> gối -> ống chân (quần ống suông) ----------
  const legs = [];
  for (const side of [-1, 1]) {
    const hip = new THREE.Group();
    hip.position.set(side * 0.085, hipY, 0);
    model.add(hip);
    const thigh = new THREE.Mesh(new THREE.CylinderGeometry(0.085, 0.09, thighLen + 0.04, 18), cloth);
    thigh.position.y = -thighLen / 2;
    hip.add(thigh);
    const knee = new THREE.Group();
    knee.position.y = -thighLen;
    hip.add(knee);
    const kneeCap = new THREE.Mesh(new THREE.SphereGeometry(0.09, 16, 10), cloth);
    knee.add(kneeCap);
    const shin = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.1, shinLen, 18), cloth);
    shin.position.y = -shinLen / 2;
    knee.add(shin);
    const hem = new THREE.Mesh(new THREE.TorusGeometry(0.1, 0.008, 8, 24), clothDark);
    hem.rotation.x = Math.PI / 2;
    hem.position.y = -shinLen + 0.005;
    knee.add(hem);
    const shoe = new THREE.Mesh(new THREE.CapsuleGeometry(0.045, 0.12, 4, 12), mat(0x3a2a20, 0.7));
    shoe.rotation.x = Math.PI / 2;
    shoe.scale.set(1, 1, 0.55);
    shoe.position.set(0, -shinLen - 0.03, 0.03);
    knee.add(shoe);
    legs.push({ hip, knee, side });
  }

  // ---------- Thân trên: xoay quanh hông để cúi/lạy ----------
  const upper = new THREE.Group();
  upper.position.y = hipY;
  model.add(upper);
  const body = new THREE.Group();
  body.position.y = -hipY; // giữ toạ độ tuyệt đối bên trong
  upper.add(body);

  const hemY = monk ? 0.34 : female ? 0.78 : 0.76;
  const shoulderY = 1.4;
  const waistR = female ? 0.15 : 0.165;
  const profile = monk
    ? [[0, hemY - 0.005], [0.24, hemY], [0.215, 0.7], [0.19, 1.02], [0.185, 1.18],
      [shoulderW, 1.33], [shoulderW - 0.02, shoulderY - 0.02], [0.07, shoulderY + 0.02], [0, shoulderY + 0.02]]
    : [[0, hemY - 0.005], [0.19, hemY], [female ? 0.175 : 0.185, hemY + 0.12], [waistR, 1.02],
      [female ? 0.165 : 0.18, 1.18], [shoulderW, 1.33], [shoulderW - 0.02, shoulderY - 0.02],
      [0.07, shoulderY + 0.02], [0, shoulderY + 0.02]];
  const torso = new THREE.Mesh(
    new THREE.LatheGeometry(profile.map(([r, y]) => new THREE.Vector2(r, y)), 40), cloth,
  );
  torso.scale.z = DEPTH;
  body.add(torso);

  const radiusAt = (y) => {
    for (let i = 0; i < profile.length - 1; i++) {
      const [r0, y0] = profile[i];
      const [r1, y1] = profile[i + 1];
      if (y >= Math.min(y0, y1) && y <= Math.max(y0, y1) && y1 !== y0) {
        return r0 + ((y - y0) / (y1 - y0)) * (r1 - r0);
      }
    }
    return waistR;
  };
  const frontZ = (y) => radiusAt(y) * DEPTH + 0.004;

  // Cổ áo chữ V + viền
  const vTop = shoulderY + 0.015;
  const vBottom = monk ? 1.18 : 1.24;
  const vHalf = 0.055;
  const vShape = new THREE.Shape();
  vShape.moveTo(-vHalf, vTop);
  vShape.lineTo(vHalf, vTop);
  vShape.lineTo(0, vBottom);
  vShape.closePath();
  const vNeck = new THREE.Mesh(new THREE.ShapeGeometry(vShape), skin);
  vNeck.position.z = frontZ((vTop + vBottom) / 2) + 0.012;
  vNeck.rotation.x = -0.12;
  body.add(vNeck);
  for (const side of [-1, 1]) {
    const pts = [
      new THREE.Vector3(side * vHalf, vTop + 0.01, frontZ(vTop) - 0.02),
      new THREE.Vector3(side * vHalf * 0.5, (vTop + vBottom) / 2, frontZ((vTop + vBottom) / 2) + 0.012),
      new THREE.Vector3(0, vBottom, frontZ(vBottom) + 0.004),
    ];
    body.add(new THREE.Mesh(
      new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 12, 0.009, 6, false), clothDark,
    ));
  }
  const collar = new THREE.Mesh(new THREE.TorusGeometry(0.068, 0.012, 8, 24, Math.PI * 1.3), clothDark);
  collar.rotation.set(-Math.PI / 2, 0, -Math.PI * 0.15);
  collar.position.y = vTop + 0.012;
  body.add(collar);

  if (!monk) {
    // Nẹp giữa + 5 nút thắt vải
    const placket = new THREE.Mesh(new THREE.BoxGeometry(0.012, vBottom - hemY, 0.004), clothDark);
    placket.position.set(0.012, (vBottom + hemY) / 2, frontZ(1.0));
    body.add(placket);
    for (let i = 0; i < 5; i++) {
      const y = vBottom - 0.015 - i * ((vBottom - (hemY + 0.14)) / 4);
      const g = new THREE.Group();
      g.add(new THREE.Mesh(new THREE.SphereGeometry(0.011, 10, 8), clothDark));
      for (const side of [-1, 1]) {
        const loop = new THREE.Mesh(new THREE.CapsuleGeometry(0.0055, 0.03, 3, 6), clothDark);
        loop.rotation.z = Math.PI / 2;
        loop.position.x = side * 0.022;
        g.add(loop);
      }
      g.position.set(0, y, frontZ(y) + 0.006);
      body.add(g);
    }
  } else {
    // Áo tràng nhà sư: vạt chéo
    const sash = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.75, 0.01), clothDark);
    sash.position.set(0.05, 0.95, frontZ(0.95) + 0.005);
    sash.rotation.z = 0.25;
    body.add(sash);
  }

  // ---------- Tay ----------
  const arms = [];
  const upperLen = 0.28;
  const foreLen = 0.25;
  for (const side of [-1, 1]) {
    const shoulder = new THREE.Group();
    shoulder.position.set(side * (shoulderW - 0.01), 1.33, 0);
    body.add(shoulder);
    const sleeveUpper = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.06, upperLen, 16), cloth);
    sleeveUpper.position.y = -upperLen / 2;
    shoulder.add(sleeveUpper);
    shoulder.add(new THREE.Mesh(new THREE.SphereGeometry(0.056, 16, 12), cloth));

    const elbow = new THREE.Group();
    elbow.position.y = -upperLen;
    shoulder.add(elbow);
    elbow.add(new THREE.Mesh(new THREE.SphereGeometry(0.058, 12, 10), cloth));
    const sleeveMat = cloth.clone();
    sleeveMat.side = THREE.DoubleSide;
    const sleeveLower = new THREE.Mesh(
      new THREE.CylinderGeometry(0.06, 0.066, monk ? 0.2 : 0.11, 16, 1, true), sleeveMat,
    );
    sleeveLower.position.y = monk ? -0.09 : -0.045;
    elbow.add(sleeveLower);
    const cuff = new THREE.Mesh(new THREE.TorusGeometry(0.066, 0.006, 6, 20), clothDark);
    cuff.rotation.x = Math.PI / 2;
    cuff.position.y = monk ? -0.19 : -0.1;
    elbow.add(cuff);
    const forearm = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.04, foreLen, 12), skin);
    forearm.position.y = -foreLen / 2;
    elbow.add(forearm);
    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.045, 14, 10), skin);
    hand.scale.set(0.8, 1.15, 0.6);
    hand.position.y = -foreLen - 0.035;
    elbow.add(hand);
    arms.push({
      side, shoulder, elbow,
      upperDir: new THREE.Vector3(...ARM_POSES.clasp.upper).setX(side * ARM_POSES.clasp.upper[0]).normalize(),
      foreDir: new THREE.Vector3(...ARM_POSES.clasp.fore).setX(side * ARM_POSES.clasp.fore[0]).normalize(),
    });
  }

  // ---------- Cổ + đầu ----------
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.05, 0.1, 14), skin);
  neck.position.y = shoulderY + 0.05;
  body.add(neck);
  const head = new THREE.Group();
  head.position.y = shoulderY + 0.17;
  body.add(head);
  const skull = new THREE.Mesh(new THREE.SphereGeometry(0.11, 32, 24), skin);
  skull.scale.set(female ? 0.9 : 0.95, 1.12, 1);
  head.add(skull);
  for (const side of [-1, 1]) {
    const ear = new THREE.Mesh(new THREE.SphereGeometry(0.022, 10, 8), skin);
    ear.scale.set(0.5, 1, 0.8);
    ear.position.set(side * (female ? 0.098 : 0.104), 0, -0.005);
    head.add(ear);
    const eyeWhite = new THREE.Mesh(new THREE.SphereGeometry(0.015, 12, 10), mat(0xffffff, 0.3));
    eyeWhite.scale.set(1.2, 0.8, 0.5);
    eyeWhite.position.set(side * 0.037, 0.012, 0.097);
    head.add(eyeWhite);
    const pupil = new THREE.Mesh(new THREE.SphereGeometry(0.0085, 10, 8), mat(0x1a120c, 0.2));
    pupil.position.set(side * 0.037, 0.012, 0.104);
    head.add(pupil);
    const brow = new THREE.Mesh(new THREE.BoxGeometry(0.035, female ? 0.005 : 0.008, 0.006), hair);
    brow.position.set(side * 0.038, 0.042, 0.1);
    brow.rotation.z = side * -0.12;
    head.add(brow);
    if (female) {
      const cheek = new THREE.Mesh(new THREE.CircleGeometry(0.014, 12), mat(0xf1a49a, 0.9));
      cheek.material.transparent = true;
      cheek.material.opacity = 0.55;
      cheek.position.set(side * 0.055, -0.022, 0.093);
      cheek.rotation.y = side * 0.5;
      head.add(cheek);
    }
  }
  const nose = new THREE.Mesh(new THREE.ConeGeometry(0.012, 0.035, 8), skin);
  nose.position.set(0, -0.005, 0.11);
  nose.rotation.x = Math.PI / 2.4;
  head.add(nose);
  const mouth = new THREE.Mesh(
    new THREE.TorusGeometry(0.018, 0.0035, 6, 16, Math.PI), mat(female ? 0xc0504d : 0x9c5a4a, 0.5),
  );
  mouth.position.set(0, -0.045, 0.098);
  mouth.rotation.z = Math.PI;
  head.add(mouth);

  if (!monk) {
    const hairCap = new THREE.Mesh(
      new THREE.SphereGeometry(0.117, 32, 16, 0, Math.PI * 2, 0, Math.PI * 0.33), hair,
    );
    hairCap.scale.set(female ? 0.93 : 0.98, 1.12, 1.03);
    hairCap.position.set(0, 0.006, -0.004);
    head.add(hairCap);
    const back = new THREE.Mesh(
      new THREE.SphereGeometry(0.116, 24, 16, Math.PI, Math.PI, 0, Math.PI * (female ? 0.75 : 0.62)), hair,
    );
    back.scale.set(female ? 0.93 : 0.98, 1.12, 1.03);
    head.add(back);
    if (female) {
      const bun = new THREE.Mesh(new THREE.SphereGeometry(0.055, 20, 16), hair);
      bun.position.set(0, -0.06, -0.115);
      head.add(bun);
      const tail = new THREE.Mesh(new THREE.CapsuleGeometry(0.04, 0.16, 4, 12), hair);
      tail.position.set(0, -0.17, -0.12);
      tail.rotation.x = 0.15;
      head.add(tail);
      for (const side of [-1, 1]) {
        const lock = new THREE.Mesh(new THREE.CapsuleGeometry(0.03, 0.14, 4, 10), hair);
        lock.scale.set(0.7, 1, 1);
        lock.position.set(side * 0.085, -0.05, -0.04);
        lock.rotation.set(0.2, 0, side * 0.08);
        head.add(lock);
      }
    }
  }

  root.traverse((o) => {
    if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; }
  });

  // ---------- Điều khiển tư thế ----------
  // walk: 0..1 (mức đi bộ), arms: 'clasp'|'down'|'pray', kneel: 0..1, bow: 0..1, idle: có thở/nhìn quanh
  const pose = { walk: 0, arms: 'clasp', kneel: 0, bow: 0, idle: true };
  let phase = 0;
  let walkAmt = 0;
  const tmpU = new THREE.Vector3();
  const tmpF = new THREE.Vector3();
  const q1 = new THREE.Quaternion();
  const q2 = new THREE.Quaternion();
  const kneelDrop = hipY - thighLen - 0.09;

  root.userData.pose = pose;
  root.userData.handsPoint = () => {
    // Điểm giữa hai bàn tay khi chắp trước ngực (toạ độ thế giới)
    const p = new THREE.Vector3(0, 1.21, 0.2);
    return body.localToWorld(p);
  };
  root.userData.update = (t, dt = 1 / 60) => {
    const k = Math.min(1, dt * 8);
    walkAmt += (pose.walk - walkAmt) * k;
    phase += dt * 9 * Math.max(walkAmt, 0.001);

    // Chân
    for (const { hip, knee, side } of legs) {
      const sw = Math.sin(phase + (side > 0 ? 0 : Math.PI));
      const walkHip = -sw * 0.45 * walkAmt;
      const walkKnee = Math.max(0, Math.sin(phase + (side > 0 ? -0.8 : Math.PI - 0.8))) * 0.7 * walkAmt;
      hip.rotation.x = walkHip * (1 - pose.kneel);
      knee.rotation.x = walkKnee * (1 - pose.kneel) + (Math.PI / 2) * pose.kneel;
    }
    model.position.y = -kneelDrop * pose.kneel * s + Math.abs(Math.sin(phase)) * 0.02 * walkAmt;

    // Thân trên: cúi lạy
    upper.rotation.x = pose.bow * (0.35 + 0.95 * pose.kneel);

    // Tay: nội suy hướng về tư thế mục tiêu
    const target = ARM_POSES[pose.arms] ?? ARM_POSES.clasp;
    for (const arm of arms) {
      const swing = pose.arms === 'down' ? Math.sin(phase + (arm.side > 0 ? Math.PI : 0)) * 0.5 * walkAmt : 0;
      tmpU.set(target.upper[0] * arm.side, target.upper[1], target.upper[2] + swing).normalize();
      tmpF.set(target.fore[0] * arm.side, target.fore[1], target.fore[2] + swing * 1.2).normalize();
      arm.upperDir.lerp(tmpU, k).normalize();
      arm.foreDir.lerp(tmpF, k).normalize();
      q1.setFromUnitVectors(Y, arm.upperDir);
      arm.shoulder.quaternion.copy(q1);
      q2.setFromUnitVectors(Y, arm.foreDir);
      arm.elbow.quaternion.copy(q1.invert()).multiply(q2);
    }

    // Thở + nhìn quanh khi đứng yên
    const b = Math.sin(t * 1.6);
    torso.scale.x = 1 + b * 0.008;
    torso.scale.z = DEPTH * (1 + b * 0.012);
    head.position.y = shoulderY + 0.17 + b * 0.003;
    head.rotation.y = pose.idle && walkAmt < 0.1 ? Math.sin(t * 0.4) * 0.12 : head.rotation.y * 0.9;
  };
  root.userData.update(0, 1);
  return root;
}

// Khung cảnh preview 3D cho màn tạo nhân vật / sảnh.
export async function createStage(canvas, { background = 0xf3ead8 } = {}) {
  const { OrbitControls } = await import('three/addons/controls/OrbitControls.js');
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFShadowMap;
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(background);
  scene.fog = new THREE.Fog(background, 6, 14);
  const camera = new THREE.PerspectiveCamera(32, 1, 0.1, 50);
  camera.position.set(0.4, 1.25, 3.6);

  const controls = new OrbitControls(camera, canvas);
  controls.target.set(0, 0.9, 0);
  controls.enablePan = false;
  controls.minDistance = 1.6;
  controls.maxDistance = 6;
  controls.maxPolarAngle = Math.PI * 0.55;
  controls.enableDamping = true;
  controls.autoRotate = true;
  controls.autoRotateSpeed = 1.2;
  controls.update();
  canvas.addEventListener('pointerdown', () => { controls.autoRotate = false; });

  scene.add(new THREE.HemisphereLight(0xfff6e5, 0x8a7560, 1.4));
  const sun = new THREE.DirectionalLight(0xffffff, 2.2);
  sun.position.set(2, 4, 3);
  sun.castShadow = true;
  sun.shadow.mapSize.set(1024, 1024);
  Object.assign(sun.shadow.camera, { left: -2, right: 2, top: 3, bottom: -1 });
  scene.add(sun);
  const floor = new THREE.Mesh(
    new THREE.CircleGeometry(1.2, 48),
    new THREE.MeshStandardMaterial({ color: 0xd8c7a6, roughness: 1 }),
  );
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  scene.add(floor);

  let character = null;
  const setCharacter = (opts) => {
    if (character) {
      scene.remove(character);
      character.traverse((o) => { if (o.isMesh) o.geometry.dispose(); });
    }
    character = createCharacter(opts);
    scene.add(character);
    return character;
  };

  const resize = () => {
    const w = canvas.clientWidth || 1;
    const h = canvas.clientHeight || 1;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  };
  new ResizeObserver(resize).observe(canvas);
  resize();

  let last = performance.now();
  const t0 = last;
  renderer.setAnimationLoop(() => {
    if (!canvas.offsetParent) return; // không vẽ khi đang ẩn
    const now = performance.now();
    character?.userData.update?.((now - t0) / 1000, Math.min(0.1, (now - last) / 1000));
    last = now;
    controls.update();
    renderer.render(scene, camera);
  });

  return { scene, camera, renderer, controls, setCharacter };
}
