import { createStage } from './character.js';
import {
  validateCharacterName, normalizeName, nameLength, NAME_MAX, OUTFIT_COLORS,
} from '/shared/validation.js';
import { TEMPLES } from '/shared/temples.js';

const $ = (id) => document.getElementById(id);
const views = ['view-auth', 'view-create', 'view-lobby', 'view-temple'];
let createStageP = null;
let lobbyStageP = null;
let currentUser = null;
let visit = null;

async function api(path, body) {
  const res = await fetch(path, {
    method: body ? 'POST' : 'GET',
    headers: body ? { 'Content-Type': 'application/json' } : {},
    body: body ? JSON.stringify(body) : undefined,
    credentials: 'same-origin',
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw Object.assign(new Error(data.error || 'Lỗi máy chủ.'), { status: res.status });
  return data;
}

function show(view) {
  for (const v of views) $(v).hidden = v !== view;
  document.body.classList.toggle('in-game', view === 'view-temple');
}

function renderTempleList() {
  const ul = $('temple-list');
  ul.replaceChildren(...TEMPLES.map((t, i) => {
    const li = document.createElement('li');
    const b = document.createElement('button');
    b.className = 'temple-item';
    b.dataset.temple = t.id;
    b.innerHTML = '<span class="num"></span><span class="txt"><b></b><small></small></span>';
    b.querySelector('.num').textContent = i + 1;
    b.querySelector('b').textContent = t.name;
    b.querySelector('small').textContent = `${t.location} — ${t.short}`;
    b.addEventListener('click', () => openTemple(t));
    li.append(b);
    return li;
  }));
}

async function openTemple(temple) {
  show('view-temple');
  const { TempleVisit } = await import('./temple/visit.js');
  visit = new TempleVisit({
    root: $('view-temple'),
    temple,
    user: currentUser,
    api,
    onExit: () => { visit = null; route(currentUser); },
  });
  try {
    await visit.start();
  } catch (err) {
    if (err.status === 401) { visit.exit(); return route(null); }
    console.error(err);
    alert(`Không mở được chùa: ${err.message}`);
    visit.exit();
  }
}

function setUser(user) {
  $('userbox').hidden = !user;
  $('who').textContent = user ? `Xin chào, ${user.username}` : '';
}

async function route(user) {
  currentUser = user;
  setUser(user);
  if (!user) return show('view-auth');
  if (!user.character) {
    show('view-create');
    createStageP ??= createStage($('stage-create'));
    const stage = await createStageP;
    stage.setCharacter(currentChoice());
    return;
  }
  show('view-lobby');
  renderTempleList();
  const c = user.character;
  $('lobby-name').textContent = c.name;
  $('lobby-info').textContent = `${c.gender === 'nu' ? 'Nữ' : 'Nam'} · Áo Phật tử màu ${OUTFIT_COLORS[c.outfit]?.label ?? ''}`;
  lobbyStageP ??= createStage($('stage-lobby'));
  (await lobbyStageP).setCharacter(c);
}

// ----- Đăng nhập / Đăng ký -----
let authMode = 'login';
for (const tab of document.querySelectorAll('.tab')) {
  tab.addEventListener('click', () => {
    authMode = tab.dataset.mode;
    document.querySelectorAll('.tab').forEach((t) => t.classList.toggle('active', t === tab));
    $('auth-submit').textContent = authMode === 'login' ? 'Đăng nhập' : 'Đăng ký';
    $('auth-pass').autocomplete = authMode === 'login' ? 'current-password' : 'new-password';
    $('auth-error').textContent = '';
  });
}

$('auth-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = $('auth-submit');
  btn.disabled = true;
  $('auth-error').textContent = '';
  try {
    const user = await api(`/api/${authMode}`, {
      username: $('auth-user').value.trim(), password: $('auth-pass').value,
    });
    $('auth-pass').value = '';
    await route(user);
  } catch (err) {
    $('auth-error').textContent = err.message;
  } finally {
    btn.disabled = false;
  }
});

$('btn-logout').addEventListener('click', async () => {
  if (visit) { const v = visit; visit = null; v.onExit = null; v.exit(); }
  await api('/api/logout', {}).catch(() => {});
  route(null);
});

// ----- Tạo nhân vật -----
let outfit = 'nau';
const swatches = $('swatches');
for (const [key, { label, hex }] of Object.entries(OUTFIT_COLORS)) {
  const b = document.createElement('button');
  b.type = 'button';
  b.className = 'swatch';
  b.style.background = hex;
  b.title = label;
  b.setAttribute('role', 'radio');
  b.setAttribute('aria-label', label);
  b.setAttribute('aria-checked', String(key === outfit));
  b.dataset.outfit = key;
  b.addEventListener('click', () => {
    outfit = key;
    swatches.querySelectorAll('.swatch').forEach((s) => s.setAttribute('aria-checked', String(s === b)));
    refreshPreview();
  });
  swatches.append(b);
}

function currentChoice() {
  return { gender: document.querySelector('input[name=gender]:checked').value, outfit };
}

async function refreshPreview() {
  if (!createStageP) return;
  (await createStageP).setCharacter(currentChoice());
}

document.querySelectorAll('input[name=gender]').forEach((r) => r.addEventListener('change', refreshPreview));

$('char-name').addEventListener('input', () => {
  const len = nameLength(normalizeName($('char-name').value));
  $('name-count').textContent = len;
  $('name-count').parentElement.classList.toggle('over', len > NAME_MAX);
  $('create-error').textContent = '';
});

$('create-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const v = validateCharacterName($('char-name').value);
  if (!v.ok) { $('create-error').textContent = v.error; return; }
  const btn = e.submitter ?? $('create-form').querySelector('button[type=submit]');
  btn.disabled = true;
  try {
    const user = await api('/api/character', { name: v.name, ...currentChoice() });
    await route(user);
  } catch (err) {
    if (err.status === 401) return route(null);
    $('create-error').textContent = err.message;
  } finally {
    btn.disabled = false;
  }
});

// ----- Khởi động -----
api('/api/me').then(route).catch(() => route(null));
