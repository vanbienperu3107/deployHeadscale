// Các hàm dựng kiến trúc chùa Việt bằng hình khối (procedural): mái cong, cổng tam quan,
// nhà Bái đường, Bảo tháp Lục độ đài sen, vườn tháp, cây Bồ đề, tượng Phật đồng, bát hương...
import * as THREE from 'three';

export const COLORS = {
  wall: 0xd9b778,      // tường vàng đất
  wallRed: 0x9c4a32,   // tường đỏ gạch (cổng)
  trim: 0x6b2a1e,
  lacquer: 0x7a1d17,   // sơn son
  gold: 0xc9a043,
  roof: 0x6e3326,
  wood: 0x5a2c1c,
  stone: 0xa59d8e,
  bronze: 0x8a6233,
};

export function mat(color, opts = {}) {
  return new THREE.MeshStandardMaterial({ color, roughness: 0.85, metalness: 0, ...opts });
}
export const bronzeMat = () => new THREE.MeshStandardMaterial({
  color: COLORS.bronze, metalness: 0.85, roughness: 0.36,
});
export const goldMat = () => new THREE.MeshStandardMaterial({
  color: COLORS.gold, metalness: 0.75, roughness: 0.35,
});

function shadowAll(obj, cast = true, receive = true) {
  obj.traverse((o) => { if (o.isMesh) { o.castShadow = cast; o.receiveShadow = receive; } });
  return obj;
}

// ---------- Chữ trên bảng (canvas texture) ----------
export function wrapLines(ctx, text, maxWidth) {
  const words = text.split(' ');
  const lines = [];
  let line = '';
  for (const w of words) {
    const test = line ? `${line} ${w}` : w;
    if (ctx.measureText(test).width > maxWidth && line) { lines.push(line); line = w; } else line = test;
  }
  if (line) lines.push(line);
  return lines;
}

export function textTexture({
  width = 1024, height = 256, bg = '#6b2a1e', fg = '#f2d27a', border = '#c9a043',
  title, titleSize = 84, body = [], bodySize = 30, align = 'center', font = '"Times New Roman", Georgia, serif',
}) {
  const c = document.createElement('canvas');
  c.width = width; c.height = height;
  const ctx = c.getContext('2d');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, width, height);
  ctx.strokeStyle = border;
  ctx.lineWidth = Math.max(6, width / 120);
  ctx.strokeRect(ctx.lineWidth, ctx.lineWidth, width - ctx.lineWidth * 2, height - ctx.lineWidth * 2);
  ctx.fillStyle = fg;
  ctx.textBaseline = 'middle';
  let y = height / 2;
  if (title) {
    ctx.font = `bold ${titleSize}px ${font}`;
    ctx.textAlign = 'center';
    const tl = wrapLines(ctx, title, width * 0.9);
    y = body.length ? titleSize * 0.9 : height / 2 - ((tl.length - 1) * titleSize * 1.1) / 2;
    for (const l of tl) { ctx.fillText(l, width / 2, y); y += titleSize * 1.1; }
  }
  if (body.length) {
    ctx.font = `${bodySize}px ${font}`;
    ctx.textAlign = align;
    const x = align === 'center' ? width / 2 : width * 0.06;
    y += bodySize * 0.2;
    for (const para of body) {
      for (const l of wrapLines(ctx, para, width * 0.88)) {
        if (y > height - bodySize) break;
        ctx.fillText(l, x, y);
        y += bodySize * 1.25;
      }
      y += bodySize * 0.4;
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

export function signBoard(w, h, texOpts) {
  const g = new THREE.Group();
  const frame = new THREE.Mesh(new THREE.BoxGeometry(w + 0.12, h + 0.12, 0.08), mat(COLORS.trim));
  g.add(frame);
  const face = new THREE.Mesh(
    new THREE.PlaneGeometry(w, h),
    new THREE.MeshStandardMaterial({ map: textTexture(texOpts), roughness: 0.7 }),
  );
  face.position.z = 0.045;
  g.add(face);
  return shadowAll(g, true, false);
}

// ---------- Mái cong kiểu đình chùa Việt (đầu đao cong vút) ----------
export function curvedRoof({
  w, d, h, overhang = 0.5, lift = 0.4, sag = 0.12, color = COLORS.roof, seg = 14, ridgeOrnament = true,
}) {
  const W = w / 2 + overhang;
  const D = d / 2 + overhang;
  const R = Math.max(0.05, W - D);
  const faces = [
    { base: (u) => [-W + 2 * W * u, D], top: (u) => [-R + 2 * R * u, 0] },
    { base: (u) => [W - 2 * W * u, -D], top: (u) => [R - 2 * R * u, 0] },
    { base: (u) => [-W, -D + 2 * D * u], top: () => [-R, 0] },
    { base: (u) => [W, D - 2 * D * u], top: () => [R, 0] },
  ];
  const pos = [];
  const idx = [];
  for (const f of faces) {
    const start = pos.length / 3;
    for (let j = 0; j <= seg; j++) {
      const v = j / seg;
      for (let i = 0; i <= seg; i++) {
        const u = i / seg;
        const [bx, bz] = f.base(u);
        const [tx, tz] = f.top(u);
        const x = bx + (tx - bx) * v;
        const z = bz + (tz - bz) * v;
        const corner = Math.abs(2 * u - 1) ** 3;
        const y = h * v - sag * Math.sin(Math.PI * v) + lift * corner * (1 - v) ** 2;
        pos.push(x, y, z);
      }
    }
    for (let j = 0; j < seg; j++) {
      for (let i = 0; i < seg; i++) {
        const a = start + j * (seg + 1) + i;
        const b = a + 1;
        const c = a + seg + 1;
        const e = c + 1;
        idx.push(a, b, c, b, e, c);
      }
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  geo.setIndex(idx);
  geo.computeVertexNormals();
  const g = new THREE.Group();
  const roof = new THREE.Mesh(geo, mat(color, { side: THREE.DoubleSide, roughness: 0.75 }));
  g.add(roof);

  const dark = mat(0x3d1c14);
  // Bờ nóc
  const ridge = new THREE.Mesh(new THREE.BoxGeometry(2 * R + 0.3, 0.16, 0.18), dark);
  ridge.position.y = h + 0.06;
  g.add(ridge);
  // Đầu đao: mũi cong vút ở 4 góc
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      const curve = new THREE.QuadraticBezierCurve3(
        new THREE.Vector3(sx * (W - 0.35), lift * 0.55, sz * (D - 0.35)),
        new THREE.Vector3(sx * (W + 0.05), lift * 0.75, sz * (D + 0.05)),
        new THREE.Vector3(sx * (W + 0.18), lift + 0.45, sz * (D + 0.18)),
      );
      g.add(new THREE.Mesh(new THREE.TubeGeometry(curve, 8, 0.06, 6), dark));
    }
  }
  if (ridgeOrnament) {
    // Hai đầu bờ nóc cong lên (đầu kìm)
    for (const sx of [-1, 1]) {
      const curve = new THREE.QuadraticBezierCurve3(
        new THREE.Vector3(sx * R, h + 0.06, 0),
        new THREE.Vector3(sx * (R + 0.25), h + 0.1, 0),
        new THREE.Vector3(sx * (R + 0.18), h + 0.5, 0),
      );
      g.add(new THREE.Mesh(new THREE.TubeGeometry(curve, 8, 0.07, 6), dark));
    }
  }
  return shadowAll(g);
}

// Bức tường có cửa vòm
function archWall(w, h, depth, archW, archH, color) {
  const s = new THREE.Shape();
  s.moveTo(-w / 2, 0);
  s.lineTo(w / 2, 0);
  s.lineTo(w / 2, h);
  s.lineTo(-w / 2, h);
  s.closePath();
  const r = archW / 2;
  const hole = new THREE.Path();
  hole.moveTo(-r, 0.001);
  hole.lineTo(r, 0.001);
  hole.lineTo(r, archH - r);
  hole.absarc(0, archH - r, r, 0, Math.PI, false);
  hole.lineTo(-r, 0.001);
  s.holes.push(hole);
  const geo = new THREE.ExtrudeGeometry(s, { depth, bevelEnabled: false, curveSegments: 16 });
  geo.translate(0, 0, -depth / 2);
  return new THREE.Mesh(geo, mat(color));
}

// ---------- Cổng tam quan ----------
export function buildGate({ signText }) {
  const g = new THREE.Group();
  g.name = 'gate';
  // Gian giữa
  const center = archWall(4.4, 4, 1.4, 1.9, 2.9, COLORS.wallRed);
  g.add(center);
  const cRoof = curvedRoof({ w: 4.4, d: 1.4, h: 0.9, overhang: 0.55, lift: 0.45 });
  cRoof.position.y = 4;
  g.add(cRoof);
  const cap = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.5, 0.9), mat(COLORS.wallRed));
  cap.position.y = 5.0;
  g.add(cap);
  const cRoof2 = curvedRoof({ w: 2.6, d: 0.9, h: 0.7, overhang: 0.45, lift: 0.4 });
  cRoof2.position.y = 5.2;
  g.add(cRoof2);
  // Bảng hiệu
  const sign = signBoard(3.6, 0.62, {
    width: 1400, height: 240, title: signText, titleSize: 96,
  });
  sign.position.set(0, 3.42, 0.74);
  g.add(sign);
  // Cột trụ hai bên gian giữa
  for (const sx of [-1, 1]) {
    const pillar = new THREE.Mesh(new THREE.BoxGeometry(0.5, 4.4, 0.5), mat(COLORS.trim));
    pillar.position.set(sx * 2.25, 2.2, 0.62);
    g.add(pillar);
    const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 10), mat(0xf6e3a2, { emissive: 0xffb84a, emissiveIntensity: 0.6 }));
    lamp.position.set(sx * 2.25, 4.55, 0.62);
    g.add(lamp);
  }
  // Hai gian bên
  for (const sx of [-1, 1]) {
    const side = archWall(2.6, 3, 1.2, 1.1, 2.1, COLORS.wallRed);
    side.position.x = sx * 3.55;
    g.add(side);
    const sRoof = curvedRoof({ w: 2.6, d: 1.2, h: 0.75, overhang: 0.45, lift: 0.35 });
    sRoof.position.set(sx * 3.55, 3, 0);
    g.add(sRoof);
    // Tường bao
    const wall = new THREE.Mesh(new THREE.BoxGeometry(8, 1.8, 0.4), mat(COLORS.wall));
    wall.position.set(sx * 8.85, 0.9, 0);
    g.add(wall);
    const wallCap = new THREE.Mesh(new THREE.BoxGeometry(8.2, 0.14, 0.6), mat(COLORS.roof));
    wallCap.position.set(sx * 8.85, 1.85, 0);
    g.add(wallCap);
  }
  return shadowAll(g);
}

// Bảng giới thiệu lịch sử (đặt bên trái cổng)
export function buildHistoryBoard(temple) {
  const g = new THREE.Group();
  g.name = 'history-board';
  for (const sx of [-1, 1]) {
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.07, 2.4, 10), mat(COLORS.wood));
    post.position.set(sx * 0.95, 1.2, -0.04);
    g.add(post);
  }
  const board = signBoard(1.9, 1.4, {
    width: 1024, height: 760, bg: '#f4ead2', fg: '#4a2a18', border: '#6b2a1e',
    title: 'GIỚI THIỆU LỊCH SỬ CHÙA TRẤN QUỐC', titleSize: 44, body: temple.history, bodySize: 26, align: 'left',
  });
  board.position.y = 1.65;
  g.add(board);
  const roof = curvedRoof({ w: 2.0, d: 0.3, h: 0.25, overhang: 0.18, lift: 0.12, sag: 0.03, ridgeOrnament: false });
  roof.position.y = 2.42;
  g.add(roof);
  return shadowAll(g);
}

// ---------- Nhà Bái đường (mặt ngoài) ----------
export function buildBaiDuong() {
  const g = new THREE.Group();
  g.name = 'bai-duong';
  const W = 11, D = 6.5;
  const base = new THREE.Mesh(new THREE.BoxGeometry(W + 1.2, 0.45, D + 1.2), mat(COLORS.stone));
  base.position.y = 0.225;
  g.add(base);
  for (let i = 0; i < 3; i++) {
    const step = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.15, 0.35), mat(COLORS.stone));
    step.position.set(0, 0.075 + i * 0.15, D / 2 + 0.6 + 0.7 - i * 0.35);
    g.add(step);
  }
  const walls = new THREE.Mesh(new THREE.BoxGeometry(W - 1, 3, D - 1.4), mat(COLORS.wall));
  walls.position.set(0, 0.45 + 1.5, -0.5);
  g.add(walls);
  // Cửa bức bàn sơn son
  for (let i = -2; i <= 2; i++) {
    const door = new THREE.Mesh(new THREE.BoxGeometry(1.4, 2.5, 0.08), mat(COLORS.lacquer));
    door.position.set(i * 1.8, 0.45 + 1.25, D / 2 - 1.18);
    g.add(door);
    const trimTop = new THREE.Mesh(new THREE.BoxGeometry(1.45, 0.08, 0.1), goldMat());
    trimTop.position.set(i * 1.8, 0.45 + 2.0, D / 2 - 1.12);
    g.add(trimTop);
  }
  // Hàng cột hiên
  for (let i = -3; i <= 3; i++) {
    const col = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.18, 3.1, 14), mat(COLORS.wood));
    col.position.set(i * 1.7, 0.45 + 1.55, D / 2 - 0.2);
    g.add(col);
    const plinth = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.26, 0.18, 12), mat(COLORS.stone));
    plinth.position.set(i * 1.7, 0.54, D / 2 - 0.2);
    g.add(plinth);
  }
  // Mái chồng diêm hai tầng
  const roof1 = curvedRoof({ w: W, d: D, h: 1.5, overhang: 0.7, lift: 0.55 });
  roof1.position.y = 3.5;
  g.add(roof1);
  const mid = new THREE.Mesh(new THREE.BoxGeometry(W - 3.6, 0.8, D - 3), mat(COLORS.wall));
  mid.position.y = 4.9;
  g.add(mid);
  const roof2 = curvedRoof({ w: W - 3.4, d: D - 2.8, h: 1.4, overhang: 0.6, lift: 0.5 });
  roof2.position.y = 5.3;
  g.add(roof2);
  // Hoành phi
  const sign = signBoard(2.8, 0.55, { width: 1100, height: 220, title: 'Nhà Bái đường', titleSize: 110 });
  sign.position.set(0, 3.15, D / 2 - 0.05);
  g.add(sign);
  // Đèn lồng
  for (const sx of [-1, 1]) {
    const lantern = new THREE.Mesh(
      new THREE.SphereGeometry(0.22, 14, 10),
      mat(0xc0281e, { emissive: 0xff3b1f, emissiveIntensity: 0.35 }),
    );
    lantern.scale.y = 1.25;
    lantern.position.set(sx * 2.6, 2.9, D / 2 - 0.2);
    g.add(lantern);
  }
  return shadowAll(g);
}

// ---------- Bảo tháp Lục độ đài sen: 11 tầng, mỗi tầng 6 ô cửa có tượng A Di Đà ----------
export function buildLotusPagoda() {
  const g = new THREE.Group();
  g.name = 'bao-thap';
  const brick = mat(0x9a4232);
  const eaveMat = mat(0x6e2a1f);
  const base1 = new THREE.Mesh(new THREE.CylinderGeometry(2.7, 2.9, 0.5, 6), mat(COLORS.stone));
  base1.position.y = 0.25;
  g.add(base1);
  const base2 = new THREE.Mesh(new THREE.CylinderGeometry(2.1, 2.3, 0.45, 6), mat(0xb8ae9c));
  base2.position.y = 0.72;
  g.add(base2);

  const nicheShape = new THREE.Shape();
  nicheShape.moveTo(-0.17, 0);
  nicheShape.lineTo(0.17, 0);
  nicheShape.lineTo(0.17, 0.32);
  nicheShape.absarc(0, 0.32, 0.17, 0, Math.PI, false);
  nicheShape.closePath();
  const nicheGeo = new THREE.ShapeGeometry(nicheShape, 10);
  const statueGeo = new THREE.CapsuleGeometry(0.07, 0.1, 4, 8);
  const headGeo = new THREE.SphereGeometry(0.05, 10, 8);
  const TIERS = 11;
  const total = TIERS * 6;
  const niches = new THREE.InstancedMesh(nicheGeo, mat(0x2a1510), total);
  const statues = new THREE.InstancedMesh(statueGeo, goldMat(), total);
  const heads = new THREE.InstancedMesh(headGeo, goldMat(), total);
  const m = new THREE.Matrix4();
  const q = new THREE.Quaternion();
  const sc = new THREE.Vector3(1, 1, 1);
  let n = 0;
  let y = 0.95;
  for (let i = 0; i < TIERS; i++) {
    const r = 1.65 - i * 0.095;
    const t = 1.02 - i * 0.03;
    const body = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.94, r, t, 6), brick);
    body.position.y = y + t / 2;
    g.add(body);
    const eave = new THREE.Mesh(new THREE.CylinderGeometry(r + 0.32, r * 0.95, 0.16, 6), eaveMat);
    eave.position.y = y + t + 0.06;
    g.add(eave);
    for (let k = 0; k < 6; k++) {
      // Đầu đao nhỏ ở 6 góc mái
      const a = (k * Math.PI) / 3;
      const tip = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.28, 6), eaveMat);
      tip.position.set(Math.sin(a) * (r + 0.36), y + t + 0.16, Math.cos(a) * (r + 0.36));
      tip.rotation.set(Math.cos(a) * 0.6, 0, -Math.sin(a) * 0.6);
      g.add(tip);
      // Ô cửa vòm + tượng A Di Đà
      const fa = a + Math.PI / 6;
      const ap = r * 0.97 * Math.cos(Math.PI / 6) + 0.012;
      q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), fa);
      m.compose(new THREE.Vector3(Math.sin(fa) * ap, y + 0.18, Math.cos(fa) * ap), q, sc);
      niches.setMatrixAt(n, m);
      const sp = ap + 0.02;
      m.compose(new THREE.Vector3(Math.sin(fa) * sp, y + 0.3, Math.cos(fa) * sp), q, sc);
      statues.setMatrixAt(n, m);
      m.compose(new THREE.Vector3(Math.sin(fa) * sp, y + 0.44, Math.cos(fa) * sp), q, sc);
      heads.setMatrixAt(n, m);
      n++;
    }
    y += t + 0.14;
  }
  g.add(niches, statues, heads);
  // Đài sen trên đỉnh
  const lotus = new THREE.Group();
  lotus.position.y = y;
  const petalGeo = new THREE.SphereGeometry(0.22, 12, 8);
  const petalMat = mat(0xe7b7a6, { roughness: 0.6 });
  for (let ring = 0; ring < 2; ring++) {
    const count = ring ? 8 : 12;
    for (let k = 0; k < count; k++) {
      const a = (k / count) * Math.PI * 2 + ring * 0.2;
      const p = new THREE.Mesh(petalGeo, petalMat);
      p.scale.set(0.55, 1.4, 0.3);
      const rr = ring ? 0.32 : 0.55;
      p.position.set(Math.sin(a) * rr, 0.28 + ring * 0.15, Math.cos(a) * rr);
      p.rotation.set(0, a, 0);
      p.rotateX(ring ? 0.35 : 0.65);
      lotus.add(p);
    }
  }
  const bud = new THREE.Mesh(new THREE.SphereGeometry(0.22, 14, 10), goldMat());
  bud.position.y = 0.5;
  bud.scale.y = 1.3;
  lotus.add(bud);
  const spire = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.9, 10), goldMat());
  spire.position.y = 1.05;
  lotus.add(spire);
  g.add(lotus);
  g.userData.height = y + 1.5;
  return shadowAll(g);
}

// ---------- Tháp mộ cổ trong vườn tháp ----------
export function buildStupa(tiers = 4, scale = 1, seed = 0) {
  const g = new THREE.Group();
  const tone = 0x9a9488 + ((seed * 0x050403) & 0x0f0f0f);
  const stone = mat(tone, { roughness: 0.95 });
  const dark = mat(0x6d6a60, { roughness: 0.95 });
  const base = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.35, 1.2), dark);
  base.position.y = 0.175;
  g.add(base);
  let y = 0.35;
  for (let i = 0; i < tiers; i++) {
    const s = 0.82 - i * 0.12;
    const h = 0.62 - i * 0.06;
    const body = new THREE.Mesh(new THREE.BoxGeometry(s, h, s), stone);
    body.position.y = y + h / 2;
    g.add(body);
    const eave = new THREE.Mesh(new THREE.BoxGeometry(s + 0.25, 0.08, s + 0.25), dark);
    eave.position.y = y + h + 0.04;
    g.add(eave);
    if (i === 0) {
      const plaque = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.35), mat(0x4d4a42));
      plaque.position.set(0, y + h / 2, s / 2 + 0.005);
      g.add(plaque);
    }
    y += h + 0.08;
  }
  const gourd = new THREE.Mesh(new THREE.SphereGeometry(0.12, 12, 10), stone);
  gourd.position.y = y + 0.1;
  g.add(gourd);
  const tip = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.3, 8), stone);
  tip.position.y = y + 0.32;
  g.add(tip);
  g.scale.setScalar(scale);
  return shadowAll(g);
}

// ---------- Cây ----------
export function buildBodhiTree() {
  const g = new THREE.Group();
  g.name = 'bo-de';
  const bark = mat(0x6b5a46, { roughness: 1 });
  const platform = new THREE.Mesh(new THREE.CylinderGeometry(1.9, 2.0, 0.4, 8), mat(COLORS.stone));
  platform.position.y = 0.2;
  g.add(platform);
  const trunkCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, 0.3, 0), new THREE.Vector3(0.15, 1.6, 0.05),
    new THREE.Vector3(-0.1, 3.0, 0.1), new THREE.Vector3(0.05, 4.2, 0),
  ]);
  g.add(new THREE.Mesh(new THREE.TubeGeometry(trunkCurve, 16, 0.32, 10), bark));
  const branches = [[1.6, 4.4, 0.6], [-1.5, 4.6, -0.4], [0.3, 5.2, -1.4], [-0.4, 4.9, 1.4]];
  for (const [x, yy, z] of branches) {
    const c = new THREE.QuadraticBezierCurve3(
      new THREE.Vector3(0, 3.4, 0), new THREE.Vector3(x * 0.4, yy - 0.3, z * 0.4), new THREE.Vector3(x, yy, z),
    );
    g.add(new THREE.Mesh(new THREE.TubeGeometry(c, 8, 0.12, 6), bark));
  }
  const leafMats = [0x3f7d32, 0x4f8f3a, 0x356b2b].map((c) => mat(c, { flatShading: true }));
  const blobs = [[0, 5.6, 0, 2.0], [1.7, 5.0, 0.6, 1.5], [-1.6, 5.2, -0.4, 1.5], [0.3, 6.3, -1.2, 1.3],
    [-0.4, 5.6, 1.5, 1.3], [1.0, 6.4, 1.0, 1.1], [-1.2, 6.2, 0.8, 1.0]];
  blobs.forEach(([x, yy, z, r], i) => {
    const b = new THREE.Mesh(new THREE.IcosahedronGeometry(r, 1), leafMats[i % 3]);
    b.position.set(x, yy, z);
    b.scale.y = 0.75;
    g.add(b);
  });
  return shadowAll(g);
}

export function buildTree(seed = 0, scale = 1) {
  const g = new THREE.Group();
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.18, 2, 8), mat(0x5c4a36));
  trunk.position.y = 1;
  g.add(trunk);
  const greens = [0x4a7f3a, 0x5b8f45, 0x3d6e33];
  for (let i = 0; i < 3; i++) {
    const b = new THREE.Mesh(new THREE.IcosahedronGeometry(0.9 - i * 0.15, 1), mat(greens[(seed + i) % 3], { flatShading: true }));
    b.position.set(Math.sin(seed + i * 2) * 0.35, 2.2 + i * 0.55, Math.cos(seed + i * 2) * 0.35);
    g.add(b);
  }
  g.scale.setScalar(scale);
  return shadowAll(g);
}

// ---------- Tượng Phật bằng đồng (ngồi kiết già trên toà sen, tay ấn thiền định) ----------
export function buildBuddha({ scale = 1, material = bronzeMat(), halo = true } = {}) {
  const g = new THREE.Group();
  const M = material;
  // Toà sen
  const drum = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.56, 0.22, 24), M);
  drum.position.y = 0.11;
  g.add(drum);
  const petalGeo = new THREE.SphereGeometry(0.13, 10, 8);
  for (let ring = 0; ring < 2; ring++) {
    const count = 14;
    for (let k = 0; k < count; k++) {
      const a = (k / count) * Math.PI * 2 + ring * (Math.PI / count);
      const p = new THREE.Mesh(petalGeo, M);
      p.scale.set(0.75, 1.3, 0.35);
      p.position.set(Math.sin(a) * (0.5 - ring * 0.06), 0.28 + ring * 0.06, Math.cos(a) * (0.5 - ring * 0.06));
      p.rotation.y = a;
      p.rotateX(0.55);
      g.add(p);
    }
  }
  // Chân xếp bằng
  const lap = new THREE.Mesh(new THREE.CapsuleGeometry(0.15, 0.5, 6, 14), M);
  lap.rotation.z = Math.PI / 2;
  lap.scale.set(1, 1, 1.5);
  lap.position.set(0, 0.42, 0.08);
  g.add(lap);
  // Thân
  const prof = [[0, 0.38], [0.3, 0.4], [0.26, 0.62], [0.29, 0.86], [0.24, 0.97], [0.09, 1.02], [0, 1.02]];
  const torso = new THREE.Mesh(new THREE.LatheGeometry(prof.map(([r, y]) => new THREE.Vector2(r, y)), 28), M);
  torso.scale.z = 0.75;
  g.add(torso);
  // Tay buông xuống lòng, hai bàn tay chồng lên nhau
  for (const sx of [-1, 1]) {
    const upperArm = new THREE.Mesh(new THREE.CapsuleGeometry(0.07, 0.3, 4, 10), M);
    upperArm.position.set(sx * 0.3, 0.75, 0.0);
    upperArm.rotation.set(0.25, 0, sx * 0.12);
    g.add(upperArm);
    const fore = new THREE.Mesh(new THREE.CapsuleGeometry(0.06, 0.24, 4, 10), M);
    fore.position.set(sx * 0.2, 0.55, 0.18);
    fore.rotation.set(1.2, 0, -sx * 0.9);
    g.add(fore);
  }
  const hands = new THREE.Mesh(new THREE.SphereGeometry(0.11, 14, 10), M);
  hands.scale.set(1.3, 0.45, 0.8);
  hands.position.set(0, 0.52, 0.27);
  g.add(hands);
  // Đầu
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.08, 0.1, 12), M);
  neck.position.y = 1.06;
  g.add(neck);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.16, 24, 18), M);
  head.scale.set(0.95, 1.12, 1);
  head.position.y = 1.22;
  g.add(head);
  const ushnisha = new THREE.Mesh(new THREE.SphereGeometry(0.085, 14, 10), M);
  ushnisha.position.y = 1.4;
  g.add(ushnisha);
  for (const sx of [-1, 1]) {
    const ear = new THREE.Mesh(new THREE.CapsuleGeometry(0.025, 0.12, 4, 8), M);
    ear.position.set(sx * 0.155, 1.17, 0);
    g.add(ear);
  }
  const nose = new THREE.Mesh(new THREE.ConeGeometry(0.022, 0.06, 8), M);
  nose.position.set(0, 1.21, 0.16);
  nose.rotation.x = Math.PI / 2.3;
  g.add(nose);
  // Nốt bạch hào
  const urna = new THREE.Mesh(new THREE.SphereGeometry(0.012, 8, 6), goldMat());
  urna.position.set(0, 1.27, 0.155);
  g.add(urna);
  if (halo) {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.025, 8, 40), goldMat());
    ring.position.set(0, 1.25, -0.2);
    g.add(ring);
    const disc = new THREE.Mesh(
      new THREE.CircleGeometry(0.3, 40),
      new THREE.MeshStandardMaterial({ color: 0xd8b25a, metalness: 0.5, roughness: 0.5, transparent: true, opacity: 0.35 }),
    );
    disc.position.set(0, 1.25, -0.21);
    g.add(disc);
  }
  g.scale.setScalar(scale);
  return shadowAll(g);
}

// ---------- Bát hương (lư hương đồng ba chân) ----------
export function buildIncenseBowl() {
  const g = new THREE.Group();
  g.name = 'bat-huong';
  const M = bronzeMat();
  const prof = [[0, 0.05], [0.16, 0.05], [0.22, 0.1], [0.24, 0.2], [0.21, 0.26], [0.23, 0.28], [0.2, 0.28], [0.19, 0.25], [0, 0.25]];
  const bowl = new THREE.Mesh(new THREE.LatheGeometry(prof.map(([r, y]) => new THREE.Vector2(r, y)), 32), M);
  g.add(bowl);
  const sand = new THREE.Mesh(new THREE.CircleGeometry(0.195, 24), mat(0xb8a07a));
  sand.rotation.x = -Math.PI / 2;
  sand.position.y = 0.255;
  g.add(sand);
  for (let k = 0; k < 3; k++) {
    const a = (k / 3) * Math.PI * 2;
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.035, 0.1, 8), M);
    leg.position.set(Math.sin(a) * 0.14, 0.04, Math.cos(a) * 0.14);
    g.add(leg);
  }
  for (const sx of [-1, 1]) {
    const handle = new THREE.Mesh(new THREE.TorusGeometry(0.05, 0.012, 6, 14, Math.PI), M);
    handle.position.set(sx * 0.24, 0.27, 0);
    handle.rotation.y = Math.PI / 2;
    g.add(handle);
  }
  g.userData.sandY = 0.255;
  return shadowAll(g);
}

// Một nén hương (thân đỏ, đầu than hồng)
export function buildIncenseStick() {
  const g = new THREE.Group();
  const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.005, 0.005, 0.1, 5), mat(0xb52a1e));
  handle.position.y = 0.05;
  g.add(handle);
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 0.22, 5), mat(0x6b4a2a));
  body.position.y = 0.21;
  g.add(body);
  const ember = new THREE.Mesh(
    new THREE.SphereGeometry(0.009, 8, 6),
    new THREE.MeshStandardMaterial({ color: 0xff6a1a, emissive: 0xff4a00, emissiveIntensity: 2.5 }),
  );
  ember.position.y = 0.325;
  g.add(ember);
  g.userData.tipY = 0.33;
  return g;
}

// Hương án (bàn thờ) sơn son thếp vàng
export function buildAltarTable(w = 2.2, d = 0.8, h = 0.95) {
  const g = new THREE.Group();
  const top = new THREE.Mesh(new THREE.BoxGeometry(w, 0.08, d), mat(COLORS.lacquer, { roughness: 0.5 }));
  top.position.y = h;
  g.add(top);
  const apron = new THREE.Mesh(new THREE.BoxGeometry(w - 0.1, 0.5, d - 0.1), mat(COLORS.lacquer, { roughness: 0.5 }));
  apron.position.y = h - 0.3;
  g.add(apron);
  const panel = new THREE.Mesh(new THREE.PlaneGeometry(w - 0.4, 0.34), goldMat());
  panel.position.set(0, h - 0.3, d / 2 - 0.045);
  g.add(panel);
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      const leg = new THREE.Mesh(new THREE.BoxGeometry(0.1, h, 0.1), mat(COLORS.lacquer));
      leg.position.set(sx * (w / 2 - 0.08), h / 2, sz * (d / 2 - 0.08));
      g.add(leg);
    }
  }
  g.userData.topY = h + 0.04;
  return shadowAll(g);
}
