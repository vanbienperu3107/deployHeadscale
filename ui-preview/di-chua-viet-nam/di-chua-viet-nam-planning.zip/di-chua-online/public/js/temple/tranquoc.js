// Ba cảnh của chùa Trấn Quốc: Cổng chùa, Sân chùa, Chính điện (trong nhà Bái đường).
// Mỗi hàm trả về "scene def" cho Engine: group, va chạm, khu vực, điểm tương tác, điểm xuất hiện.
import * as THREE from 'three';
import { createCharacter } from '../character.js';
import {
  COLORS, mat, goldMat, buildGate, buildHistoryBoard, buildBaiDuong, buildLotusPagoda, buildStupa,
  buildBodhiTree, buildTree, buildBuddha, buildIncenseBowl, buildIncenseStick, buildAltarTable,
  curvedRoof, signBoard,
} from './builders.js';

// ---------- tiện ích chung ----------
function tileTexture({ base = '#b9ae98', line = '#9d927d', tiles = 8, noise = 0.08 } = {}) {
  const c = document.createElement('canvas');
  c.width = c.height = 256;
  const ctx = c.getContext('2d');
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, 256, 256);
  const s = 256 / tiles;
  for (let i = 0; i < tiles; i++) {
    for (let j = 0; j < tiles; j++) {
      ctx.fillStyle = `rgba(0,0,0,${Math.random() * noise})`;
      ctx.fillRect(i * s + 1, j * s + 1, s - 2, s - 2);
    }
  }
  ctx.strokeStyle = line;
  ctx.lineWidth = 2;
  for (let i = 0; i <= tiles; i++) {
    ctx.beginPath(); ctx.moveTo(i * s, 0); ctx.lineTo(i * s, 256); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0, i * s); ctx.lineTo(256, i * s); ctx.stroke();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function groundPlane(w, d, { color = 0x7fa05a, tex = null, repeat = 1, y = 0 } = {}) {
  const m = new THREE.MeshStandardMaterial({ color: tex ? 0xffffff : color, roughness: 1, map: tex });
  if (tex) tex.repeat.set(repeat * (w / d), repeat);
  const p = new THREE.Mesh(new THREE.PlaneGeometry(w, d), m);
  p.rotation.x = -Math.PI / 2;
  p.position.y = y;
  p.receiveShadow = true;
  return p;
}

function sunLight(group, { x = 12, y = 22, z = 14, size = 26, intensity = 2.4 } = {}) {
  group.add(new THREE.HemisphereLight(0xfff4e0, 0x6b7a4a, 1.3));
  const sun = new THREE.DirectionalLight(0xfff1d6, intensity);
  sun.position.set(x, y, z);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  Object.assign(sun.shadow.camera, { left: -size, right: size, top: size, bottom: -size, near: 1, far: 80 });
  sun.shadow.bias = -0.0005;
  group.add(sun);
}

function water(w, d, x, z) {
  const m = new THREE.Mesh(
    new THREE.PlaneGeometry(w, d),
    new THREE.MeshStandardMaterial({ color: 0x5f8fa3, roughness: 0.15, metalness: 0.3, transparent: true, opacity: 0.92 }),
  );
  m.rotation.x = -Math.PI / 2;
  m.position.set(x, -0.15, z);
  return m;
}

function lanternPost(x, z) {
  const g = new THREE.Group();
  const stone = mat(0x9b9385);
  const base = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.2, 0.4), stone);
  base.position.y = 0.1;
  const post = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 1.0, 8), stone);
  post.position.y = 0.7;
  const box = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.3, 0.34), mat(0xf3d9a0, { emissive: 0xffb048, emissiveIntensity: 0.5 }));
  box.position.y = 1.35;
  const cap = new THREE.Mesh(new THREE.ConeGeometry(0.34, 0.25, 4), stone);
  cap.position.y = 1.62;
  cap.rotation.y = Math.PI / 4;
  g.add(base, post, box, cap);
  g.position.set(x, 0, z);
  g.traverse((o) => { if (o.isMesh) o.castShadow = true; });
  return g;
}

// Khói hương: hệ hạt đơn giản bay lên từ các đầu hương đang cháy.
function smokeSystem(max = 160) {
  const c = document.createElement('canvas');
  c.width = c.height = 64;
  const ctx = c.getContext('2d');
  const grd = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
  grd.addColorStop(0, 'rgba(255,255,255,0.8)');
  grd.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = grd;
  ctx.fillRect(0, 0, 64, 64);
  const geo = new THREE.BufferGeometry();
  const pos = new Float32Array(max * 3);
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  const pts = new THREE.Points(geo, new THREE.PointsMaterial({
    size: 0.09, map: new THREE.CanvasTexture(c), transparent: true, opacity: 0.45, depthWrite: false, color: 0xe8e4dc,
  }));
  pts.frustumCulled = false;
  const life = new Float32Array(max).fill(-1);
  const vel = new Float32Array(max * 3);
  let cursor = 0;
  pts.userData.emitters = [];
  pts.userData.update = (dt) => {
    const em = pts.userData.emitters;
    if (em.length) {
      const spawn = Math.min(max, Math.ceil(dt * 30 * Math.min(em.length, 6)));
      for (let i = 0; i < spawn; i++) {
        const e = em[Math.floor(Math.random() * em.length)];
        const k = cursor++ % max;
        pos[k * 3] = e.x; pos[k * 3 + 1] = e.y; pos[k * 3 + 2] = e.z;
        vel[k * 3] = (Math.random() - 0.5) * 0.05;
        vel[k * 3 + 1] = 0.25 + Math.random() * 0.15;
        vel[k * 3 + 2] = (Math.random() - 0.5) * 0.05;
        life[k] = 2.5 + Math.random();
      }
    }
    for (let k = 0; k < max; k++) {
      if (life[k] <= 0) { pos[k * 3 + 1] = -100; continue; }
      life[k] -= dt;
      pos[k * 3] += vel[k * 3] * dt + Math.sin(life[k] * 3 + k) * 0.002;
      pos[k * 3 + 1] += vel[k * 3 + 1] * dt;
      pos[k * 3 + 2] += vel[k * 3 + 2] * dt;
    }
    geo.attributes.position.needsUpdate = true;
  };
  return pts;
}

// =====================================================================
// 1) CỔNG CHÙA
// =====================================================================
export function gateScene(temple, ui) {
  const g = new THREE.Group();
  sunLight(g, { x: 10, y: 18, z: 16, size: 18 });
  g.add(groundPlane(80, 60, { color: 0x86a565 }));
  const path = groundPlane(4.2, 18, { tex: tileTexture(), repeat: 4, y: 0.01 });
  path.position.z = 8;
  g.add(path);
  const plaza = groundPlane(22, 4, { tex: tileTexture(), repeat: 2, y: 0.012 });
  plaza.position.z = 1.8;
  g.add(plaza);

  const gate = buildGate({ signText: temple.gateSign });
  g.add(gate);
  const board = buildHistoryBoard(temple);
  board.position.set(-4.6, 0, 2.6);
  board.rotation.y = 0.25;
  g.add(board);

  // Cây xanh, đèn đá, mặt hồ Tây phía xa
  [[-9, 6], [9, 6], [-12, 10], [12, 10], [-7, 13], [7, 14], [-14, 3], [14, 3]].forEach(([x, z], i) => {
    const t = buildTree(i, 1.1 + (i % 3) * 0.15);
    t.position.set(x, 0, z);
    g.add(t);
  });
  for (const z of [5, 9, 13]) { g.add(lanternPost(-2.6, z)); g.add(lanternPost(2.6, z)); }
  g.add(water(120, 30, 0, 32));
  // Mái chùa thấp thoáng phía sau tường
  const backRoof = curvedRoof({ w: 10, d: 5, h: 1.6, overhang: 0.6, lift: 0.5 });
  backRoof.position.set(0, 3.2, -12);
  g.add(backRoof);
  const pagodaTop = buildLotusPagoda();
  pagodaTop.position.set(9, 0, -14);
  pagodaTop.scale.setScalar(0.9);
  g.add(pagodaTop);

  return {
    id: 'gate',
    name: 'Cổng chùa',
    group: g,
    sky: 0xcfe3ef,
    fog: [30, 90],
    camera: { dist: 7.5, pitch: 0.22, targetY: 1.8, minDist: 3, maxDist: 12 },
    bounds: { minX: -11, maxX: 11, minZ: 1.2, maxZ: 16 },
    colliders: [
      { type: 'box', minX: -14, maxX: 14, minZ: -0.8, maxZ: 0.8 },
      { type: 'box', minX: -5.6, maxX: -3.6, minZ: 2.2, maxZ: 3.0 },
    ],
    zones: [],
    interactables: [
      {
        id: 'history', label: 'Đọc bảng giới thiệu lịch sử', x: -4.0, z: 4.0, r: 2.0,
        pick: board, labelPos: [-4.6, 3.3, 2.6], labelText: 'Bảng giới thiệu',
        action: () => ui.openHistory(),
      },
      {
        id: 'enter', label: 'Vào Chùa', x: 0, z: 2.2, r: 1.8, pick: gate,
        labelPos: [0, 3.0, 1.7], labelText: 'Vào Chùa', labelClass: 'enter',
        action: () => ui.enterTemple(),
      },
    ],
    spawns: {
      default: { x: 0, z: 10, yaw: Math.PI },
      back: { x: 0, z: 3.2, yaw: Math.PI },
    },
  };
}

// =====================================================================
// 2) SÂN CHÙA (tổng thể các khu vực)
// =====================================================================
export function courtyardScene(temple, ui) {
  const g = new THREE.Group();
  sunLight(g, { x: 14, y: 24, z: 12, size: 26 });
  g.add(groundPlane(36, 40, { color: 0x86a565 }));
  const stone = tileTexture({ base: '#c2b6a0', line: '#a39780' });
  const mainPath = groundPlane(3.6, 24, { tex: stone, repeat: 6, y: 0.01 });
  mainPath.position.set(0, 0.01, 8);
  g.add(mainPath);
  const crossPath = groundPlane(26, 3, { tex: stone.clone(), repeat: 2, y: 0.012 });
  crossPath.position.set(0, 0.012, 1.5);
  g.add(crossPath);
  // Bán đảo giữa Hồ Tây
  g.add(water(140, 140, 0, 0));
  const shore = new THREE.Mesh(new THREE.BoxGeometry(37, 0.3, 41), mat(0x8e8676));
  shore.position.y = -0.16;
  g.add(shore);

  // Nhà Bái đường
  const bai = buildBaiDuong();
  bai.position.set(0, 0, -8);
  g.add(bai);
  // Bảo tháp Lục độ đài sen
  const thap = buildLotusPagoda();
  thap.position.set(10.5, 0, -4);
  g.add(thap);
  // Cây Bồ đề
  const bode = buildBodhiTree();
  bode.position.set(-10.5, 0, -3);
  g.add(bode);
  // Khu Vườn tháp (tháp mộ cổ)
  const vuon = new THREE.Group();
  const stupaColliders = [];
  const grid = [[-12.5, 8], [-10.5, 8], [-8.5, 8], [-12.5, 10.5], [-10.5, 10.5], [-8.5, 10.5], [-11.5, 13], [-9.5, 13]];
  grid.forEach(([x, z], i) => {
    const s = buildStupa(3 + (i % 3), 0.85 + (i % 2) * 0.2, i);
    s.position.set(x, 0, z);
    s.rotation.y = (i % 2) * 0.1;
    vuon.add(s);
    stupaColliders.push({ type: 'circle', x, z, r: 0.6 });
  });
  const vuonGround = groundPlane(7.5, 8.5, { tex: tileTexture({ base: '#a8a08e', line: '#8f8775', tiles: 6 }), repeat: 2, y: 0.011 });
  vuonGround.position.set(-10.5, 0.011, 10.5);
  vuon.add(vuonGround);
  g.add(vuon);

  // Cây cảnh, đèn đá, cổng phía sau người chơi
  [[6, 14], [-5, 17], [6, 18], [14, 8], [14, 14], [-15, 1], [5, -14], [-6, -14], [15, -12]].forEach(([x, z], i) => {
    const t = buildTree(i + 3, 1 + (i % 3) * 0.15);
    t.position.set(x, 0, z);
    g.add(t);
  });
  for (const z of [4, 9, 14]) { g.add(lanternPost(-2.4, z)); g.add(lanternPost(2.4, z)); }
  const gateBack = buildGate({ signText: temple.gateSign });
  gateBack.position.set(0, 0, 20.5);
  gateBack.rotation.y = Math.PI;
  g.add(gateBack);

  // NPC chú tiểu hướng dẫn
  const npc = createCharacter({ gender: 'nam', monk: true });
  npc.position.set(3.2, 0, 11);
  npc.rotation.y = -Math.PI / 2;
  g.add(npc);
  const npcMarker = new THREE.Mesh(
    new THREE.ConeGeometry(0.12, 0.25, 4),
    new THREE.MeshStandardMaterial({ color: 0xffc83d, emissive: 0xffa000, emissiveIntensity: 0.8 }),
  );
  npcMarker.rotation.x = Math.PI;
  npcMarker.position.set(3.2, 2.05, 11);
  g.add(npcMarker);

  const zoneOf = (id) => temple.zones[id];
  return {
    id: 'courtyard',
    name: 'Sân chùa',
    group: g,
    sky: 0xcfe3ef,
    fog: [40, 110],
    camera: { dist: 7, pitch: 0.3, targetY: 1.5, minDist: 3, maxDist: 16 },
    bounds: { minX: -16, maxX: 16, minZ: -15, maxZ: 19 },
    colliders: [
      { type: 'box', minX: -6.7, maxX: 6.7, minZ: -12.6, maxZ: -3.4 },
      { type: 'circle', x: 10.5, z: -4, r: 2.9 },
      { type: 'circle', x: -10.5, z: -3, r: 2.0 },
      { type: 'circle', x: 3.2, z: 11, r: 0.45 },
      { type: 'box', minX: -14, maxX: 14, minZ: 19.6, maxZ: 21.4 },
      ...stupaColliders,
    ],
    zones: [
      { id: 'bai-duong', name: zoneOf('bai-duong').name, x: 0, z: -8, r: 0, labelY: 8.6 },
      { id: 'vuon-thap', name: zoneOf('vuon-thap').name, x: -10.5, z: 10.5, r: 4.4, labelY: 3.6 },
      { id: 'bao-thap', name: zoneOf('bao-thap').name, x: 10.5, z: -4, r: 5.2, labelY: thap.userData.height + 1 },
      { id: 'bo-de', name: zoneOf('bo-de').name, x: -10.5, z: -3, r: 4.2, labelY: 7.8 },
    ],
    interactables: [
      {
        id: 'npc', label: `Nói chuyện với ${temple.npc.name}`, x: 3.2, z: 11, r: 2.2, pick: npc,
        labelPos: [3.2, 2.5, 11], labelText: temple.npc.name, labelClass: 'npc',
        action: () => ui.openNpc(),
      },
      {
        id: 'bai-duong-door', label: 'Vào nhà Bái đường', x: 0, z: -2.6, r: 1.9, pick: bai,
        action: () => ui.openBaiDuong(),
      },
      {
        id: 'exit', label: 'Ra cổng chùa', x: 0, z: 18.2, r: 1.6,
        labelPos: [0, 2.4, 19.2], labelText: 'Cổng ra',
        action: () => ui.goScene('gate', 'back'),
      },
    ],
    spawns: {
      default: { x: 0, z: 11.5, yaw: 0, cameraYaw: Math.PI },
      fromHall: { x: 0, z: -1.6, yaw: 0 },
    },
    update(t, dt, engine) {
      npc.userData.update(t, dt);
      npcMarker.position.y = 2.05 + Math.sin(t * 2.5) * 0.06;
      npcMarker.rotation.y += dt * 1.5;
      // NPC quay mặt về phía người chơi khi lại gần
      const p = engine.player.position;
      if (Math.hypot(p.x - npc.position.x, p.z - npc.position.z) < 4) {
        const yaw = Math.atan2(p.x - npc.position.x, p.z - npc.position.z);
        npc.rotation.y += Math.atan2(Math.sin(yaw - npc.rotation.y), Math.cos(yaw - npc.rotation.y)) * Math.min(1, dt * 4);
      }
    },
  };
}

// =====================================================================
// 3) CHÍNH ĐIỆN – bên trong nhà Bái đường: tượng Phật đồng, hương án, bát hương
// =====================================================================
export function hallScene(temple, ui) {
  const g = new THREE.Group();
  const W = 12, D = 13, H = 5.6;
  const floorTex = tileTexture({ base: '#8a3a2a', line: '#6a2a1e', tiles: 6, noise: 0.12 });
  g.add(groundPlane(W, D, { tex: floorTex, repeat: 3 }));
  const wallMat = mat(0xb5884a, { side: THREE.DoubleSide });
  const lacquer = mat(COLORS.lacquer, { roughness: 0.55 });
  const back = new THREE.Mesh(new THREE.PlaneGeometry(W, H), mat(0x7a2a1c));
  back.position.set(0, H / 2, -D / 2);
  g.add(back);
  for (const sx of [-1, 1]) {
    const side = new THREE.Mesh(new THREE.PlaneGeometry(D, H), wallMat);
    side.position.set(sx * W / 2, H / 2, 0);
    side.rotation.y = -sx * Math.PI / 2;
    g.add(side);
  }
  // Mặt trước để mở (third-person camera cần nhìn xuyên qua lối vào nhà Bái đường).
  // Khung cửa sáng đánh dấu lối ra sân chùa.
  // Cửa ra (sáng)
  const door = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 2.6), new THREE.MeshBasicMaterial({ color: 0xfff1cf }));
  door.position.set(0, 1.3, D / 2 - 0.01);
  door.rotation.y = Math.PI;
  g.add(door);
  const ceiling = new THREE.Mesh(new THREE.PlaneGeometry(W, D), mat(0x4a2016, { side: THREE.DoubleSide }));
  ceiling.rotation.x = Math.PI / 2;
  ceiling.position.y = H;
  g.add(ceiling);
  // Cột sơn son + xà ngang
  for (const sx of [-1, 1]) {
    for (const z of [-3.6, 0, 3.6]) {
      const col = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.22, H, 16), lacquer);
      col.position.set(sx * 3.6, H / 2, z);
      g.add(col);
    }
    const beam = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.35, D), mat(COLORS.wood));
    beam.position.set(sx * 3.6, H - 0.2, 0);
    g.add(beam);
  }
  // Hoành phi
  const sign = signBoard(3.2, 0.6, { width: 1100, height: 210, title: 'Chính điện', titleSize: 120 });
  sign.position.set(0, 4.7, -D / 2 + 0.06);
  g.add(sign);
  // Câu đối hai bên
  for (const sx of [-1, 1]) {
    const cd = signBoard(0.38, 2.4, {
      width: 160, height: 1000, title: sx < 0 ? 'Từ bi' : 'Hỷ xả', titleSize: 96, bg: '#7a1d17',
    });
    cd.position.set(sx * 3.6, 2.6, -3.6 + 0.24);
    g.add(cd);
  }

  // Bệ thờ nhiều tầng + các pho tượng Phật bằng đồng
  const altar = new THREE.Group();
  const tiers = [
    { w: 9, d: 2.4, h: 0.55, z: -4.9 },
    { w: 7, d: 1.8, h: 0.55, z: -5.3 },
    { w: 5.4, d: 1.3, h: 0.6, z: -5.65 },
  ];
  let ty = 0;
  for (const t of tiers) {
    const b = new THREE.Mesh(new THREE.BoxGeometry(t.w, t.h, t.d), lacquer);
    b.position.set(0, ty + t.h / 2, t.z);
    altar.add(b);
    const trim = new THREE.Mesh(new THREE.BoxGeometry(t.w + 0.02, 0.06, 0.04), goldMat());
    trim.position.set(0, ty + t.h - 0.05, t.z + t.d / 2);
    altar.add(trim);
    ty += t.h;
    t.top = ty;
  }
  // Tam Thế Phật (quá khứ, hiện tại, vị lai) trên tầng cao nhất
  for (const x of [-1.7, 0, 1.7]) {
    const b = buildBuddha({ scale: x === 0 ? 1.25 : 1.1 });
    b.position.set(x, tiers[2].top, -5.7);
    altar.add(b);
  }
  // Các pho tượng nhỏ hơn ở tầng dưới
  for (const x of [-2.9, 2.9]) {
    const b = buildBuddha({ scale: 0.8 });
    b.position.set(x, tiers[1].top, -5.25);
    altar.add(b);
  }
  for (const x of [-3.6, -1.2, 1.2, 3.6]) {
    const b = buildBuddha({ scale: 0.55, halo: false });
    b.position.set(x, tiers[0].top, -4.4);
    altar.add(b);
  }
  // Hoa sen, nến trên bệ
  for (const x of [-0.9, 0.9]) {
    const vase = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.12, 0.35, 12), goldMat());
    vase.position.set(x, tiers[0].top + 0.18, -4.0);
    altar.add(vase);
    const flower = new THREE.Mesh(new THREE.SphereGeometry(0.14, 10, 8), mat(0xf0a4b8));
    flower.position.set(x, tiers[0].top + 0.48, -4.0);
    altar.add(flower);
  }
  altar.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
  g.add(altar);

  // Hương án + bát hương "dưới chân các tượng"
  const table = buildAltarTable(2.6, 0.9, 0.95);
  table.position.set(0, 0, -3.3);
  g.add(table);
  const bowl = buildIncenseBowl();
  bowl.position.set(0, table.userData.topY, -3.3);
  bowl.scale.setScalar(1.25);
  g.add(bowl);
  const sandY = table.userData.topY + bowl.userData.sandY * 1.25;
  for (const x of [-1.0, 1.0]) {
    const candle = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.3, 10), mat(0xc0281e));
    candle.position.set(x, table.userData.topY + 0.15, -3.3);
    g.add(candle);
    const flame = new THREE.Mesh(
      new THREE.SphereGeometry(0.03, 8, 6),
      new THREE.MeshStandardMaterial({ color: 0xffc04a, emissive: 0xffa020, emissiveIntensity: 3 }),
    );
    flame.scale.y = 1.8;
    flame.position.set(x, table.userData.topY + 0.34, -3.3);
    g.add(flame);
  }
  // Chiếu lạy (bồ đoàn) trước hương án
  const mat1 = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.05, 0.8), mat(0xc79a3a));
  mat1.position.set(0, 0.025, -1.45);
  mat1.receiveShadow = true;
  g.add(mat1);

  // Ánh sáng ấm
  g.add(new THREE.HemisphereLight(0xffe2b8, 0x3a1a10, 0.9));
  const spot = new THREE.SpotLight(0xffd9a0, 60, 14, 0.65, 0.5, 1.2);
  spot.position.set(0, 5.2, 0.5);
  spot.target.position.set(0, 1.5, -5.5);
  spot.castShadow = true;
  spot.shadow.mapSize.set(1024, 1024);
  g.add(spot, spot.target);
  for (const x of [-2.5, 2.5]) {
    const pl = new THREE.PointLight(0xffb060, 6, 7, 1.5);
    pl.position.set(x, 2.6, -2.8);
    g.add(pl);
  }
  const fill = new THREE.PointLight(0xfff0d8, 8, 12, 1.4);
  fill.position.set(0, 3.5, 4);
  g.add(fill);

  // Hương đã cắm + khói
  const smoke = smokeSystem();
  g.add(smoke);
  const planted = new THREE.Group();
  g.add(planted);
  const MAX_STICKS = 15;
  const refreshEmitters = () => {
    smoke.userData.emitters = planted.children.map((s) => s.localToWorld(new THREE.Vector3(0, s.userData.tipY, 0)));
  };

  let held = null; // nhóm 3 nén hương đang cầm trên tay

  const def = {
    id: 'hall',
    name: 'Chính điện – nhà Bái đường',
    group: g,
    sky: 0x2a140c,
    camera: { dist: 3.6, pitch: 0.28, targetY: 1.35, minDist: 1.8, maxDist: 4.8, ceiling: H - 0.4 },
    bounds: { minX: -5.4, maxX: 5.4, minZ: -2.7, maxZ: 5.8 },
    colliders: [
      { type: 'box', minX: -1.35, maxX: 1.35, minZ: -3.8, maxZ: -2.85 },
      ...[-1, 1].flatMap((sx) => [-3.6, 0, 3.6].map((z) => ({ type: 'circle', x: sx * 3.6, z, r: 0.25 }))),
    ],
    zones: [],
    interactables: [
      {
        id: 'incense', label: 'Thắp hương và vái Phật', x: 0, z: -2.0, r: 1.6, pick: bowl,
        labelPos: [0, 1.75, -3.3], labelText: 'Bát hương',
        action: (engine) => def.offerIncense(engine),
      },
      {
        id: 'exit', label: 'Ra ngoài sân chùa', x: 0, z: 5.6, r: 1.3,
        labelPos: [0, 2.9, 6.3], labelText: 'Cửa ra',
        action: () => ui.goScene('courtyard', 'fromHall'),
      },
    ],
    spawns: { default: { x: 0, z: 4.6, yaw: Math.PI } },
    update(t, dt, engine) {
      if (held) {
        // Hương luôn dựng thẳng trong tay (theo tư thế chắp tay)
        const hp = engine.player.userData.handsPoint();
        held.position.copy(hp).add(new THREE.Vector3(0, -0.06, 0));
        held.rotation.set(0, engine.player.rotation.y, 0);
      }
      smoke.userData.update(dt);
      if (held) {
        smoke.userData.emitters = [
          ...planted.children.map((s) => s.localToWorld(new THREE.Vector3(0, s.userData.tipY, 0))),
          ...held.children.map((s) => s.localToWorld(new THREE.Vector3(0, s.userData.tipY, 0))),
        ];
      }
    },

    // Chuỗi nghi thức: đến trước bát hương -> thắp hương -> khấn -> cắm hương -> lùi lại -> quỳ, lạy 3 lạy -> đứng dậy
    async offerIncense(engine) {
      if (engine.busy) return;
      engine.busy = true;
      ui.ritualStatus('Bước tới trước bát hương…');
      const pose = engine.player.userData.pose;
      try {
        // Điểm dừng ở phía trước hương án. Tránh collider của hương án (z <= -2.85).
        // Chuyển tới vị trí trước hương án bằng animation (không dùng collision để chuỗi nghi thức không bị kẹt).
        const fromPos = engine.player.position.clone();
        await engine.tween(1.3, (k) => { engine.player.position.lerpVectors(fromPos, new THREE.Vector3(0, 0, -2.2), k); }, (k) => k);
        await engine.turnTo(Math.PI, 0.3);
        engine.cam.yaw = Math.PI;

        ui.ritualStatus('Thắp 3 nén hương…');
        pose.arms = 'pray';
        held = new THREE.Group();
        for (const dx of [-0.03, 0, 0.03]) {
          const s = buildIncenseStick();
          s.position.x = dx;
          s.rotation.z = dx * 3;
          held.add(s);
        }
        g.add(held);
        await engine.wait(0.9);

        ui.ritualStatus('Chắp tay khấn nguyện…');
        for (let i = 0; i < 3; i++) {
          await engine.tween(0.45, (k) => { pose.bow = 0.45 * k; });
          await engine.tween(0.45, (k) => { pose.bow = 0.45 * (1 - k); });
        }

        ui.ritualStatus('Cắm hương vào bát hương…');
        await engine.tween(0.5, (k) => { pose.bow = 0.35 * k; });
        const from = held.position.clone();
        const sticks = [...held.children];
        g.remove(held);
        const tmp = new THREE.Group();
        tmp.position.copy(from);
        tmp.rotation.y = engine.player.rotation.y;
        sticks.forEach((s) => tmp.add(s));
        g.add(tmp);
        held = null;
        const to = new THREE.Vector3((Math.random() - 0.5) * 0.18, sandY - 0.09, -3.3 + (Math.random() - 0.5) * 0.12);
        await engine.tween(0.9, (k) => { tmp.position.lerpVectors(from, to, k); });
        // Chuyển vào nhóm hương đã cắm
        sticks.forEach((s) => {
          s.position.add(tmp.position);
          s.rotation.y = tmp.rotation.y;
          planted.add(s);
        });
        g.remove(tmp);
        while (planted.children.length > MAX_STICKS) planted.remove(planted.children[0]);
        planted.updateMatrixWorld(true);
        refreshEmitters();
        await engine.tween(0.4, (k) => { pose.bow = 0.35 * (1 - k); });

        ui.ritualStatus('Lùi lại, quỳ trên chiếu…');
        await engine.stepBack(0, -1.45, 1.0);
        await engine.tween(0.8, (k) => { pose.kneel = k; });

        for (let i = 1; i <= 3; i++) {
          ui.ritualStatus(`Lạy lạy thứ ${i}…`);
          await engine.tween(0.7, (k) => { pose.bow = k; });
          await engine.wait(0.35);
          await engine.tween(0.7, (k) => { pose.bow = 1 - k; });
          await engine.wait(0.2);
        }
        ui.ritualStatus('Đứng dậy…');
        await engine.tween(0.8, (k) => { pose.kneel = 1 - k; });
        pose.arms = 'down';
      } finally {
        pose.bow = 0;
        pose.kneel = 0;
        pose.arms = 'down';
        if (held) { g.remove(held); held = null; }
        engine.busy = false;
      }
      await ui.incenseDone();
    },
  };
  return def;
}
