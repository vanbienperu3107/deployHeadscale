// Engine nhỏ cho màn đi chùa: renderer, camera góc nhìn thứ ba, điều khiển nhân vật
// (bàn phím WASD/mũi tên, hoặc bấm/chạm lên mặt đất để đi tới), va chạm đơn giản,
// điểm tương tác, nhãn tên khu vực (CSS2D) và tween cho hoạt ảnh.
import * as THREE from 'three';
import { CSS2DRenderer, CSS2DObject } from 'three/addons/renderers/CSS2DRenderer.js';
import { createCharacter } from '../character.js';

const PLAYER_R = 0.3;
const SPEED = 2.6;

export class Engine {
  constructor(container, { character, onPrompt, onZoneEnter, onTick } = {}) {
    this.container = container;
    this.onPrompt = onPrompt ?? (() => {});
    this.onZoneEnter = onZoneEnter ?? (() => {});
    this.onTick = onTick ?? (() => {});

    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.domElement.className = 'game-canvas';
    container.append(this.renderer.domElement);

    this.labels = new CSS2DRenderer();
    this.labels.domElement.className = 'game-labels';
    container.append(this.labels.domElement);
    // CSS2DRenderer ghi inline style nên không thể dựa vào offsetParent để nhận biết màn đang ẩn.
    this.active = true;

    this.camera = new THREE.PerspectiveCamera(50, 1, 0.1, 400);
    this.scene = new THREE.Scene();
    this.player = createCharacter(character);
    this.player.userData.pose.arms = 'down';

    this.keys = new Set();
    this.moveTarget = null;
    this.busy = false; // khoá điều khiển khi đang chạy hoạt ảnh
    this.tweens = [];
    this.cam = { yaw: Math.PI, pitch: 0.32, dist: 5.5, minDist: 2.5, maxDist: 10 };
    this.raycaster = new THREE.Raycaster();
    this.ground = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
    this.current = null;
    this.nearest = null;
    this.insideZones = new Set();
    this.clickMarker = this.#makeClickMarker();

    this.#bindInput();
    this.resizeObs = new ResizeObserver(() => this.resize());
    this.resizeObs.observe(container);
    this.resize();

    this.last = performance.now();
    this.t0 = this.last;
    this.renderer.setAnimationLoop(() => this.#frame());
  }

  // ---------- Cảnh ----------
  setScene(def, spawnKey = 'default') {
    if (this.current) {
      this.scene.remove(this.player);
      disposeTree(this.scene);
    }
    this.labels.domElement.replaceChildren();
    this.scene = new THREE.Scene();
    this.current = def;
    this.scene.background = new THREE.Color(def.sky ?? 0xcfe3ef);
    if (def.fog) this.scene.fog = new THREE.Fog(def.sky ?? 0xcfe3ef, def.fog[0], def.fog[1]);
    this.scene.add(def.group);
    this.scene.add(this.player);
    this.scene.add(this.clickMarker);
    this.clickMarker.visible = false;
    for (const z of def.zones ?? []) {
      const lbl = this.#addLabel(z.label ?? z.name, z.labelPos ?? [z.x, z.labelY ?? 4, z.z], z.labelClass);
      lbl.element.classList.add('clickable');
      lbl.element.title = 'Xem giới thiệu';
      lbl.element.addEventListener('pointerdown', (e) => e.stopPropagation());
      lbl.element.addEventListener('click', (e) => { e.stopPropagation(); this.onZoneEnter(z, true); });
      lbl.element.addEventListener('touchend', (e) => { e.preventDefault(); e.stopPropagation(); this.onZoneEnter(z, true); });
    }
    for (const it of def.interactables ?? []) {
      if (it.labelPos) {
        const lbl = this.#addLabel(it.labelText ?? it.label, it.labelPos, it.labelClass);
        lbl.element.classList.add('clickable');
        lbl.element.title = it.label;
        lbl.element.addEventListener('pointerdown', (e) => e.stopPropagation());
        lbl.element.addEventListener('click', (e) => { e.stopPropagation(); this.interact(it); });
      }
    }
    const sp = def.spawns?.[spawnKey] ?? def.spawns?.default ?? { x: 0, z: 0, yaw: Math.PI };
    this.teleport(sp.x, sp.z, sp.yaw);
    Object.assign(this.cam, def.camera ?? {});
    this.cam.yaw = Number.isFinite(sp.cameraYaw) ? sp.cameraYaw : sp.yaw;
    this.moveTarget = null;
    this.insideZones = new Set();
    // Đánh dấu các khu vực đang đứng sẵn bên trong (không bật thông báo lại khi vừa vào cảnh)
    for (const z of def.zones ?? []) if (dist2(this.player.position, z) < z.r * z.r) this.insideZones.add(z.id);
    this.nearest = null;
    this.onPrompt(null);
  }

  teleport(x, z, yaw) {
    this.player.position.set(x, 0, z);
    this.player.rotation.y = yaw;
  }

  #addLabel(text, [x, y, z], cls = '') {
    const el = document.createElement('div');
    el.className = `zone-label ${cls}`;
    el.textContent = text;
    const obj = new CSS2DObject(el);
    obj.position.set(x, y, z);
    this.scene.add(obj);
    return obj;
  }

  #makeClickMarker() {
    const m = new THREE.Mesh(
      new THREE.RingGeometry(0.18, 0.26, 24),
      new THREE.MeshBasicMaterial({ color: 0xffe08a, transparent: true, opacity: 0.85, side: THREE.DoubleSide }),
    );
    m.rotation.x = -Math.PI / 2;
    m.position.y = 0.02;
    return m;
  }

  // ---------- Hoạt ảnh ----------
  tween(duration, fn, ease = easeInOut) {
    // requestAnimationFrame riêng để chuỗi nghi thức không phụ thuộc vào render loop của WebGL.
    return new Promise((resolve) => {
      const start = performance.now();
      const tick = (now) => {
        const k = Math.min(1, (now - start) / (duration * 1000));
        fn(ease(k));
        if (k < 1) requestAnimationFrame(tick); else resolve();
      };
      requestAnimationFrame(tick);
    });
  }
  wait(sec) { return this.tween(sec, () => {}); }

  // Đi tới điểm (x,z) theo đường thẳng, dùng trong chuỗi hoạt ảnh
  async walkTo(x, z, speed = 1.6) {
    const p = this.player.position;
    const sx = p.x, sz = p.z;
    const d = Math.hypot(x - sx, z - sz);
    if (d < 0.01) return;
    const yaw = Math.atan2(x - sx, z - sz);
    await this.turnTo(yaw, 0.25);
    this.player.userData.pose.walk = 1;
    await this.tween(d / speed, (k) => { p.x = sx + (x - sx) * k; p.z = sz + (z - sz) * k; }, (k) => k);
    this.player.userData.pose.walk = 0;
  }
  async stepBack(x, z, sec = 1.1) {
    const p = this.player.position;
    const sx = p.x, sz = p.z;
    this.player.userData.pose.walk = 0.5;
    await this.tween(sec, (k) => { p.x = sx + (x - sx) * k; p.z = sz + (z - sz) * k; });
    this.player.userData.pose.walk = 0;
  }
  turnTo(yaw, sec = 0.3) {
    const from = this.player.rotation.y;
    const delta = wrapAngle(yaw - from);
    return this.tween(sec, (k) => { this.player.rotation.y = from + delta * k; });
  }

  // ---------- Input ----------
  #bindInput() {
    const el = this.renderer.domElement;
    this.onKeyDown = (e) => {
      if (isTyping(e)) return;
      const k = e.key.toLowerCase();
      if (['w', 'a', 's', 'd', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright'].includes(k)) {
        this.keys.add(k);
        this.moveTarget = null;
        e.preventDefault();
      }
      if ((k === 'e' || k === 'enter') && this.nearest && !this.busy) {
        e.preventDefault();
        this.interact();
      }
    };
    this.onKeyUp = (e) => this.keys.delete(e.key.toLowerCase());
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', () => this.keys.clear());

    let down = null;
    el.addEventListener('pointerdown', (e) => {
      down = { x: e.clientX, y: e.clientY, yaw: this.cam.yaw, pitch: this.cam.pitch, moved: false, id: e.pointerId };
      el.setPointerCapture(e.pointerId);
    });
    el.addEventListener('pointermove', (e) => {
      if (!down || down.id !== e.pointerId) return;
      const dx = e.clientX - down.x;
      const dy = e.clientY - down.y;
      if (Math.abs(dx) + Math.abs(dy) > 6) down.moved = true;
      if (down.moved) {
        this.cam.yaw = down.yaw - dx * 0.006;
        this.cam.pitch = clamp(down.pitch + dy * 0.004, 0.05, 1.1);
      }
    });
    el.addEventListener('pointerup', (e) => {
      if (down && !down.moved && !this.busy) this.#clickMove(e);
      down = null;
    });
    el.addEventListener('pointercancel', () => { down = null; });
    el.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.cam.dist = clamp(this.cam.dist * (e.deltaY > 0 ? 1.1 : 0.9), this.cam.minDist, this.cam.maxDist);
    }, { passive: false });
  }

  #clickMove(e) {
    const r = this.renderer.domElement.getBoundingClientRect();
    const ndc = new THREE.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
    this.raycaster.setFromCamera(ndc, this.camera);
    // Bấm vào vật có thể tương tác -> đi tới điểm đứng của nó
    const picks = (this.current?.interactables ?? []).filter((i) => i.pick);
    const objs = picks.map((i) => i.pick);
    const hit = objs.length ? this.raycaster.intersectObjects(objs, true)[0] : null;
    if (hit) {
      const it = picks.find((i) => isDescendant(hit.object, i.pick));
      if (it) {
        this.moveTarget = new THREE.Vector3(it.x, 0, it.z);
        this.pendingInteract = it;
        this.#showMarker(this.moveTarget);
        return;
      }
    }
    const p = new THREE.Vector3();
    if (this.raycaster.ray.intersectPlane(this.ground, p)) {
      this.moveTarget = p;
      this.pendingInteract = null;
      this.#showMarker(p);
    }
  }
  #showMarker(p) {
    this.clickMarker.position.set(p.x, 0.02, p.z);
    this.clickMarker.visible = true;
  }

  async interact(it = this.nearest) {
    if (!it || this.busy) return;
    this.moveTarget = null;
    this.pendingInteract = null;
    this.keys.clear();
    await it.action?.(this, it);
  }

  // ---------- Vòng lặp ----------
  #frame() {
    const now = performance.now();
    const dt = Math.min(0.05, (now - this.last) / 1000);
    this.last = now;
    const t = (now - this.t0) / 1000;
    if (!this.active || !this.container.isConnected) return;

    // Tween
    for (let i = this.tweens.length - 1; i >= 0; i--) {
      const tw = this.tweens[i];
      tw.t += dt;
      const k = Math.min(1, tw.t / tw.duration);
      tw.fn(tw.ease(k));
      if (k >= 1) { this.tweens.splice(i, 1); tw.resolve(); }
    }

    if (!this.busy) this.#movePlayer(dt);
    this.player.userData.update(t, dt);
    this.current?.update?.(t, dt, this);
    this.#updateCamera();
    this.#checkInteractions();
    this.onTick(this);
    this.renderer.render(this.scene, this.camera);
    this.labels.render(this.scene, this.camera);
  }

  #movePlayer(dt) {
    const p = this.player.position;
    const dir = new THREE.Vector3();
    const f = (this.keys.has('w') || this.keys.has('arrowup') ? 1 : 0) - (this.keys.has('s') || this.keys.has('arrowdown') ? 1 : 0);
    const r = (this.keys.has('d') || this.keys.has('arrowright') ? 1 : 0) - (this.keys.has('a') || this.keys.has('arrowleft') ? 1 : 0);
    if (f || r) {
      const fy = this.cam.yaw;
      dir.set(Math.sin(fy) * f - Math.cos(fy) * r, 0, Math.cos(fy) * f + Math.sin(fy) * r);
    } else if (this.moveTarget) {
      dir.set(this.moveTarget.x - p.x, 0, this.moveTarget.z - p.z);
      if (dir.length() < 0.15) {
        this.moveTarget = null;
        this.clickMarker.visible = false;
        dir.set(0, 0, 0);
        const it = this.pendingInteract;
        this.pendingInteract = null;
        if (it) this.interact(it);
      }
    }
    const moving = dir.lengthSq() > 0;
    this.player.userData.pose.walk = moving ? 1 : 0;
    if (!moving) return;
    dir.normalize();
    const before = p.clone();
    p.addScaledVector(dir, SPEED * dt);
    this.#collide(p);
    // Bị kẹt khi bấm đi tới điểm -> huỷ
    if (this.moveTarget && p.distanceTo(before) < SPEED * dt * 0.1) {
      this.moveTarget = null;
      this.clickMarker.visible = false;
    }
    const yaw = Math.atan2(dir.x, dir.z);
    this.player.rotation.y += wrapAngle(yaw - this.player.rotation.y) * Math.min(1, dt * 12);
  }

  #collide(p) {
    const def = this.current;
    if (!def) return;
    for (const c of def.colliders ?? []) {
      if (c.type === 'circle') {
        const dx = p.x - c.x, dz = p.z - c.z;
        const d = Math.hypot(dx, dz);
        const min = c.r + PLAYER_R;
        if (d < min && d > 1e-6) { p.x = c.x + (dx / d) * min; p.z = c.z + (dz / d) * min; }
      } else {
        const minX = c.minX - PLAYER_R, maxX = c.maxX + PLAYER_R;
        const minZ = c.minZ - PLAYER_R, maxZ = c.maxZ + PLAYER_R;
        if (p.x > minX && p.x < maxX && p.z > minZ && p.z < maxZ) {
          const pen = [p.x - minX, maxX - p.x, p.z - minZ, maxZ - p.z];
          const i = pen.indexOf(Math.min(...pen));
          if (i === 0) p.x = minX; else if (i === 1) p.x = maxX; else if (i === 2) p.z = minZ; else p.z = maxZ;
        }
      }
    }
    const b = def.bounds;
    if (b) {
      p.x = clamp(p.x, b.minX, b.maxX);
      p.z = clamp(p.z, b.minZ, b.maxZ);
    }
  }

  #updateCamera() {
    const target = this.player.position.clone();
    target.y += this.current?.camera?.targetY ?? 1.3;
    const { yaw, pitch, dist } = this.cam;
    this.camera.position.set(
      target.x - Math.sin(yaw) * Math.cos(pitch) * dist,
      target.y + Math.sin(pitch) * dist,
      target.z - Math.cos(yaw) * Math.cos(pitch) * dist,
    );
    const ceil = this.current?.camera?.ceiling;
    if (ceil) this.camera.position.y = Math.min(this.camera.position.y, ceil);
    this.camera.lookAt(target);
  }

  #checkInteractions() {
    const def = this.current;
    if (!def) return;
    const p = this.player.position;
    let best = null;
    let bestD = Infinity;
    if (!this.busy) {
      for (const it of def.interactables ?? []) {
        if (it.enabled && !it.enabled()) continue;
        const d = Math.hypot(p.x - it.x, p.z - it.z);
        if (d < it.r && d < bestD) { best = it; bestD = d; }
      }
    }
    if (best !== this.nearest) {
      this.nearest = best;
      this.onPrompt(best);
    }
    for (const z of def.zones ?? []) {
      const inside = dist2(p, z) < z.r * z.r;
      if (inside && !this.insideZones.has(z.id)) {
        this.insideZones.add(z.id);
        this.onZoneEnter(z);
      } else if (!inside && dist2(p, z) > (z.r + 1.5) ** 2) {
        this.insideZones.delete(z.id);
      }
    }
  }

  resize() {
    const w = this.container.clientWidth || 1;
    const h = this.container.clientHeight || 1;
    this.renderer.setSize(w, h);
    this.labels.setSize(w, h);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  dispose() {
    this.active = false;
    this.renderer.setAnimationLoop(null);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    this.resizeObs.disconnect();
    disposeTree(this.scene);
    this.renderer.dispose();
    this.container.replaceChildren();
  }
}

// ---------- tiện ích ----------
export function easeInOut(k) { return k < 0.5 ? 2 * k * k : 1 - (-2 * k + 2) ** 2 / 2; }
function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
function wrapAngle(a) { return Math.atan2(Math.sin(a), Math.cos(a)); }
function dist2(p, z) { return (p.x - z.x) ** 2 + (p.z - z.z) ** 2; }
function isDescendant(o, root) { for (let x = o; x; x = x.parent) if (x === root) return true; return false; }
function isTyping(e) { return /^(INPUT|TEXTAREA|SELECT)$/.test(e.target?.tagName ?? ''); }

export function disposeTree(root) {
  root.traverse((o) => {
    if (o.isMesh || o.isInstancedMesh) {
      o.geometry?.dispose();
      const ms = Array.isArray(o.material) ? o.material : [o.material];
      for (const m of ms) { m?.map?.dispose(); m?.dispose(); }
    }
  });
}
