// Điều phối một chuyến đi chùa: chuyển cảnh, hộp thoại, nhiệm vụ NPC, chứng nhận.
import { Engine } from './engine.js';
import { gateScene, courtyardScene, hallScene } from './tranquoc.js';
import { questComplete } from '/shared/temples.js';

const SCENES = { gate: gateScene, courtyard: courtyardScene, hall: hallScene };

export class TempleVisit {
  constructor({ root, temple, user, api, onExit }) {
    this.root = root;
    this.temple = temple;
    this.user = user;
    this.api = api;
    this.onExit = onExit;
    this.progress = null;
    this.$ = (sel) => root.querySelector(sel);
  }

  async start() {
    this.root.innerHTML = TEMPLATE;
    this.$('[data-title]').textContent = this.temple.name;
    this.engine = new Engine(this.$('.game-view'), {
      character: this.user.character,
      onPrompt: (it) => this.#prompt(it),
      onZoneEnter: (z, clicked) => this.#zoneEnter(z, clicked),
    });
    this.$('[data-act=leave]').addEventListener('click', () => this.exit());
    this.$('[data-act=quest]').addEventListener('click', () => this.#toggleQuest());
    this.$('[data-act=help]').addEventListener('click', () => this.#help());
    this.$('.prompt button').addEventListener('click', () => this.engine.interact());
    this.onKey = (e) => { if (e.key === 'Escape') this.closeModal(); };
    window.addEventListener('keydown', this.onKey);

    this.progress = await this.api(`/api/temples/${this.temple.id}/progress`);
    this.#renderQuest();
    this.goScene('gate');
    this.toast('Dùng phím W A S D / mũi tên hoặc bấm lên mặt đất để di chuyển. Kéo chuột để xoay góc nhìn.', 6000);
  }

  exit() {
    window.removeEventListener('keydown', this.onKey);
    this.engine?.dispose();
    this.root.replaceChildren();
    this.onExit?.();
  }

  goScene(id, spawn) {
    this.closeModal();
    const def = SCENES[id](this.temple, this);
    this.sceneId = id;
    this.engine.setScene(def, spawn);
    this.$('[data-place]').textContent = def.name;
    this.root.dataset.scene = id;
  }

  // ---------- Hành động từ cảnh ----------
  openHistory() {
    const t = this.temple;
    this.modal(`
      <h2>${esc(t.historyTitle)}</h2>
      <div class="history">${t.history.map((p) => `<p>${esc(p)}</p>`).join('')}</div>
      <p class="closing"><strong>${esc(t.closingNote)}</strong></p>
      <div class="actions"><button data-close>Thoát Giới thiệu</button></div>`, { wide: true });
    this.#step('read-history');
  }

  enterTemple() {
    this.goScene('courtyard');
    this.toast('Bạn đã vào trong chùa. Phía trước là nhà Bái đường, chú tiểu đứng bên phải lối đi.', 5000);
  }

  openBaiDuong() {
    const z = this.temple.zones['bai-duong'];
    this.modal(`
      <h2>${esc(z.name)}</h2>
      <img class="illus" src="${z.image}" alt="Ảnh minh hoạ ${esc(z.name)}">
      <p>${esc(z.desc)}</p>
      <div class="actions">
        <button data-go-hall>Vào nhà Bái đường</button>
        <button class="ghost" data-close>Ở lại sân chùa</button>
      </div>`, { wide: true });
    this.$('[data-go-hall]').addEventListener('click', () => this.goScene('hall'));
  }

  openNpc() {
    const npc = this.temple.npc;
    const p = this.progress;
    const done = questComplete(this.temple, p);
    let body;
    if (!p.accepted) {
      body = `<p>${esc(npc.greeting)}</p>${this.#questList()}
        <div class="actions"><button data-accept>Nhận nhiệm vụ</button><button class="ghost" data-close>Để sau</button></div>`;
    } else if (!done) {
      body = `<p>${esc(npc.inProgress)}</p>${this.#questList()}
        <div class="actions"><button data-close>Đã hiểu</button></div>`;
    } else {
      body = `<p>${esc(npc.done)}</p>
        <div class="actions"><button data-cert>Nhận Giấy chứng nhận</button><button class="ghost" data-close>Đóng</button></div>`;
    }
    this.modal(`<div class="npc-head"><span class="npc-avatar">🙏</span><h2>${esc(npc.name)}</h2></div>${body}`);
    this.$('[data-accept]')?.addEventListener('click', async () => {
      this.progress = await this.api(`/api/temples/${this.temple.id}/quest/accept`, {});
      this.#renderQuest(true);
      this.openNpc();
    });
    this.$('[data-cert]')?.addEventListener('click', () => this.showCertificate());
  }

  ritualStatus(text) {
    const el = this.$('.ritual');
    el.hidden = !text;
    el.textContent = text ?? '';
  }

  async incenseDone() {
    this.ritualStatus(null);
    try {
      this.progress = await this.api(`/api/temples/${this.temple.id}/incense`, {});
      this.#renderQuest();
    } catch (e) { this.toast(e.message); }
    const n = this.progress?.incense ?? 1;
    this.modal(`
      <h2>Đã thắp hương và vái Phật</h2>
      <p>Bạn đã dâng hương và lạy 3 lạy trước các pho tượng Phật. ${n > 1 ? `Đây là lần thứ ${n} bạn thắp hương tại chùa.` : ''}</p>
      <div class="actions">
        <button data-again>Thắp hương và vái Phật tiếp</button>
        <button class="ghost" data-out>Ra ngoài thăm các khu vực khác</button>
        <button class="ghost" data-close>Ở lại Chính điện</button>
      </div>`);
    this.$('[data-again]').addEventListener('click', () => {
      this.closeModal();
      this.engine.interact(this.engine.current.interactables.find((i) => i.id === 'incense'));
    });
    this.$('[data-out]').addEventListener('click', () => this.goScene('courtyard', 'fromHall'));
    this.#maybeAllDone();
  }

  async showCertificate() {
    try {
      this.progress = await this.api(`/api/temples/${this.temple.id}/certificate`, {});
    } catch (e) { this.toast(e.message); return; }
    const url = renderCertificate(this.progress.certificate, this.user.character);
    this.modal(`
      <h2>Giấy chứng nhận đã đến chùa</h2>
      <p class="cert-code">Mã chứng nhận: <b>${esc(this.progress.certificate.code)}</b></p>
      <img class="cert" src="${url}" alt="Giấy chứng nhận">
      <div class="actions">
        <a class="btn" href="${url}" download="chung-nhan-${this.temple.id}.png">Tải về (PNG)</a>
        <button class="ghost" data-close>Đóng</button>
      </div>`, { wide: true });
    this.#renderQuest();
  }

  // ---------- Nội bộ ----------
  async #step(step) {
    if (this.progress?.steps?.[step]) return;
    try {
      this.progress = await this.api(`/api/temples/${this.temple.id}/step`, { step });
      this.#renderQuest();
      const q = this.temple.quest.find((x) => x.id === step);
      if (this.progress.accepted) this.toast(`✔ Hoàn thành: ${q.label}`);
      this.#maybeAllDone();
    } catch (e) { this.toast(e.message); }
  }

  #maybeAllDone() {
    if (questComplete(this.temple, this.progress) && !this.progress.certificate) {
      this.toast(`Bạn đã hoàn thành mọi việc! Hãy quay lại gặp ${this.temple.npc.name} ở sân chùa để nhận chứng nhận.`, 7000);
    }
  }

  #zoneEnter(z, clicked) {
    const info = this.temple.zones[z.id];
    // Đánh dấu bước ngay khi người chơi mở thông tin: không để việc render modal che request API.
    if (z.id !== 'bai-duong' && (clicked || this.#near(z))) void this.#step(`visit-${z.id}`);
    if (!info) return;
    if (!info) return;
    if (z.id === 'bai-duong') { this.openBaiDuong(); return; }
    this.modal(`<h2>${esc(info.name)}</h2><p>${esc(info.desc)}</p><div class="actions"><button data-close>Tiếp tục tham quan</button></div>`);
    // Bấm nhãn khu vực là chủ ý xem thông tin, trên màn nhỏ không bắt buộc phải điều khiển nhân vật thật sát nhãn.
  }

  #near(z) {
    const p = this.engine.player.position;
    return Math.hypot(p.x - z.x, p.z - z.z) < z.r + 0.5;
  }

  #prompt(it) {
    const el = this.$('.prompt');
    el.hidden = !it;
    if (it) el.querySelector('span').textContent = it.label;
  }

  #questList() {
    const s = this.progress?.steps ?? {};
    return `<ul class="quest-list">${this.temple.quest
      .map((q) => `<li class="${s[q.id] ? 'done' : ''}">${s[q.id] ? '✔' : '○'} ${esc(q.label)}</li>`).join('')}</ul>`;
  }

  #renderQuest(open = false) {
    const p = this.progress;
    const panel = this.$('.quest-panel');
    const total = this.temple.quest.length;
    const done = this.temple.quest.filter((q) => p.steps?.[q.id]).length;
    this.$('[data-act=quest]').textContent = p.certificate ? 'Chứng nhận ✔' : `Nhiệm vụ ${done}/${total}`;
    panel.innerHTML = p.accepted
      ? `<h3>Nhiệm vụ viếng chùa</h3>${this.#questList()}${p.certificate
        ? '<button data-cert-view>Xem chứng nhận</button>'
        : questComplete(this.temple, p) ? `<p class="muted">Gặp ${esc(this.temple.npc.name)} để nhận chứng nhận.</p>` : ''}`
      : `<h3>Nhiệm vụ</h3><p class="muted">Hãy vào chùa và gặp ${esc(this.temple.npc.name)} (dấu ▼ vàng) để nhận nhiệm vụ.</p>${this.#questList()}`;
    panel.querySelector('[data-cert-view]')?.addEventListener('click', () => this.showCertificate());
    if (open) panel.hidden = false;
  }

  #toggleQuest() {
    const panel = this.$('.quest-panel');
    panel.hidden = !panel.hidden;
  }

  #help() {
    this.modal(`<h2>Hướng dẫn</h2><ul>
      <li><b>Di chuyển:</b> phím W A S D hoặc mũi tên; hoặc bấm/chạm lên mặt đất.</li>
      <li><b>Góc nhìn:</b> kéo chuột (hoặc vuốt) để xoay, cuộn chuột để phóng to/thu nhỏ.</li>
      <li><b>Tương tác:</b> đến gần đối tượng rồi bấm nút hiện ra ở dưới màn hình (hoặc phím E).</li>
      <li><b>Tên khu vực:</b> bấm vào nhãn tên trên cảnh để xem giới thiệu.</li>
    </ul><div class="actions"><button data-close>Đóng</button></div>`);
  }

  modal(html, { wide = false } = {}) {
    const m = this.$('.modal');
    m.querySelector('.modal-card').innerHTML = html;
    m.querySelector('.modal-card').classList.toggle('wide', wide);
    m.hidden = false;
    m.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => this.closeModal()));
    m.querySelector('button, a')?.focus();
  }
  closeModal() { this.$('.modal').hidden = true; }

  toast(text, ms = 3500) {
    const el = this.$('.toast');
    el.textContent = text;
    el.hidden = false;
    clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => { el.hidden = true; }, ms);
  }
}

const TEMPLATE = `
<div class="game">
  <div class="game-view"></div>
  <div class="hud-top">
    <button class="ghost" data-act="leave">← Danh sách chùa</button>
    <div class="place"><b data-title></b> · <span data-place></span></div>
    <div class="hud-right">
      <button class="ghost" data-act="help">?</button>
      <button data-act="quest">Nhiệm vụ</button>
    </div>
  </div>
  <div class="quest-panel" hidden></div>
  <div class="prompt" hidden><button><span></span> <kbd>E</kbd></button></div>
  <div class="ritual" hidden></div>
  <div class="toast" hidden></div>
  <div class="modal" hidden><div class="modal-card" role="dialog" aria-modal="true"></div></div>
</div>`;

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
}

// Vẽ giấy chứng nhận ra PNG (canvas)
export function renderCertificate(cert, character) {
  const W = 1600, H = 1100;
  const c = document.createElement('canvas');
  c.width = W; c.height = H;
  const x = c.getContext('2d');
  const grd = x.createLinearGradient(0, 0, 0, H);
  grd.addColorStop(0, '#fbf3df');
  grd.addColorStop(1, '#f1e1bd');
  x.fillStyle = grd;
  x.fillRect(0, 0, W, H);
  x.strokeStyle = '#9a6248';
  x.lineWidth = 18;
  x.strokeRect(40, 40, W - 80, H - 80);
  x.strokeStyle = '#c9a043';
  x.lineWidth = 4;
  x.strokeRect(72, 72, W - 144, H - 144);
  // Hoa sen trang trí
  x.save();
  x.translate(W / 2, 210);
  x.fillStyle = '#e7a6a0';
  for (let i = -3; i <= 3; i++) {
    x.save();
    x.rotate(i * 0.32);
    x.beginPath();
    x.ellipse(0, -50, 24, 62, 0, 0, Math.PI * 2);
    x.fill();
    x.restore();
  }
  x.fillStyle = '#c9a043';
  x.beginPath(); x.arc(0, 8, 22, 0, Math.PI * 2); x.fill();
  x.restore();

  const serif = '"Times New Roman", Georgia, serif';
  x.textAlign = 'center';
  x.fillStyle = '#7a4a34';
  x.font = `bold 40px ${serif}`;
  x.fillText('ĐI CHÙA VIỆT NAM', W / 2, 320);
  x.fillStyle = '#6b2a1e';
  x.font = `bold 84px ${serif}`;
  x.fillText('GIẤY CHỨNG NHẬN', W / 2, 420);
  x.font = `italic 40px ${serif}`;
  x.fillStyle = '#4a2a18';
  x.fillText('Chứng nhận Phật tử', W / 2, 510);
  x.font = `bold 76px ${serif}`;
  x.fillStyle = '#9a3a24';
  x.fillText(cert.characterName, W / 2, 610);
  x.font = `40px ${serif}`;
  x.fillStyle = '#4a2a18';
  x.fillText(`đã hoàn thành hành trình viếng ${cert.templeName}`, W / 2, 690);
  x.font = `32px ${serif}`;
  x.fillText('thắp hương lễ Phật và tham quan các khu vực của chùa.', W / 2, 745);
  const d = new Date(cert.issuedAt);
  x.font = `30px ${serif}`;
  x.fillText(`Ngày ${d.getDate()} tháng ${d.getMonth() + 1} năm ${d.getFullYear()}`, W / 2, 850);
  x.font = `24px ${serif}`;
  x.fillStyle = '#7a6a5a';
  x.fillText(`Mã chứng nhận: ${cert.code}`, W / 2, 900);
  x.font = `italic 22px ${serif}`;
  x.fillText('Chứng nhận trong trò chơi – hãy đến chùa ở ngoài đời để trải nghiệm thật sự.', W / 2, 960);
  // Dấu son
  x.save();
  x.translate(W - 290, 860);
  x.rotate(-0.15);
  x.strokeStyle = 'rgba(180,30,20,0.85)';
  x.fillStyle = 'rgba(180,30,20,0.85)';
  x.lineWidth = 6;
  x.beginPath(); x.arc(0, 0, 90, 0, Math.PI * 2); x.stroke();
  x.beginPath(); x.arc(0, 0, 76, 0, Math.PI * 2); x.stroke();
  x.font = `bold 28px ${serif}`;
  x.textBaseline = 'middle';
  const words = cert.templeName.toUpperCase().split(' ');
  const mid = Math.ceil(words.length / 2);
  x.fillText(words.slice(0, mid).join(' '), 0, -16);
  x.fillText(words.slice(mid).join(' '), 0, 22);
  x.restore();
  void character;
  return c.toDataURL('image/png');
}
