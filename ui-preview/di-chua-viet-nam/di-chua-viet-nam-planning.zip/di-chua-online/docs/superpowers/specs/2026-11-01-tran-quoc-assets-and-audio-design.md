# Nâng cấp asset và âm thanh — Chùa Trấn Quốc

**Ngày:** 2026-11-01  
**Trạng thái:** Chờ người dùng duyệt đặc tả  
**Phạm vi:** Game web “Đi chùa Việt Nam”, hành trình Chùa Trấn Quốc

## 1. Mục tiêu

Thay thế vẻ ngoài hình khối màu phẳng của cảnh hiện có bằng vật liệu PBR phong cách cổ kính, trang nghiêm; đồng thời thêm âm thanh nền cho toàn bộ khuôn viên. Bản phân phối phải chạy local qua Node/Docker Ubuntu 24.04 và không phụ thuộc tài nguyên CDN khi chạy.

Người chơi vẫn dùng cùng luồng hiện có: tạo nhân vật → chọn Chùa Trấn Quốc → cổng → sân → Chính điện → nhiệm vụ → giấy chứng nhận.

## 2. Quyết định đã chốt

- Chất lượng asset ưu tiên cao: texture 2K là mặc định; texture 4K chỉ dùng trên bề mặt lớn/nhìn gần (mái, sàn Chính điện) nếu tổng archive sau nén không vượt 200 MB.
- Chỉ đóng gói asset có quyền sử dụng cho phép phân phối lại trong source/archive.
- Ưu tiên CC0. Asset CC BY chỉ dùng khi metadata tác giả/URL/license được ghi trong game và `ATTRIBUTION.md`.
- Không lấy audio/video YouTube hoặc stock asset không có quyền phân phối lại rõ ràng.
- Khi không có bản tụng kinh tiếng Việt CC0/CC BY xác minh được, dùng ambience không lời (chuông, gió, chim, nước) và tiếng tụng/niệm không lời do tổng hợp nội bộ, không giả là bản ghi từ chùa thật.
- Tất cả âm thanh chỉ bắt đầu sau cử chỉ đầu tiên của người chơi, có bật/tắt và chỉnh âm lượng.

## 3. Nguồn asset và giấy phép

### Texture PBR

Nguồn chính: Poly Haven. Tài liệu API nêu asset là CC0; không yêu cầu attribution. Mỗi asset được lưu local dưới `public/assets/textures/` kèm URL, license, checksum trong manifest.

| Vai trò | Asset ứng viên | Resolution | Bề mặt |
|---|---|---:|---|
| Mái ngói | `roof_tiles` | 4K albedo/normal/roughness | Tam quan, Bái đường, bảo tháp |
| Lối đi đá | `patterned_cobblestone` hoặc `stone_pavers` | 2K | Sân, lối vào, vườn tháp |
| Tường gạch | `stacked_brick_wall` | 2K | Tường bao, bệ tháp |
| Gỗ sẫm | `rosewood_veneer_02` | 2K | Cột, cửa, hương án, hoành phi |
| Sàn gỗ | `plank_flooring` | 4K | Chính điện |
| Cỏ/đất | `grass_ground`, `rocky_trail` | 2K | Bãi cỏ, đường ven hồ |
| Đá/tiểu cảnh | `large_pebbles` | 2K | Bờ hồ, chân cây, vườn tháp |
| Bầu trời/ánh sáng | HDRI Poly Haven | 2K HDR | Ánh sáng, environment map |

Nếu API không có asset dưới đúng ID hoặc tải thất bại, tải asset thay thế cùng nhóm từ Poly Haven, cập nhật manifest và test asset reference.

### Audio

Audio chia tách theo layer:

1. **Môi trường ngoài trời:** chim, gió nhẹ, nước hồ, chuông xa.
2. **Không gian thờ tự:** chuông/khánh rất nhẹ, reverb mô phỏng không gian kín.
3. **Tụng/niệm:** chỉ dùng recording CC0/CC BY có thể phân phối lại. Nếu không có nguồn hợp lệ, dùng âm thanh drone/chuông tổng hợp không lời, label “Âm nền thiền tĩnh” thay vì “tụng kinh”.

Nguồn tìm kiếm phải được xác minh bằng trang license hoặc metadata file trước khi đưa vào. Toàn bộ file audio chuyển/giữ dạng OGG Vorbis, có loop metadata/điểm loop trong manifest.

## 4. Kiến trúc runtime

### AssetRegistry

Module `public/js/assets/registry.js`:

- Nạp một lần các `TextureLoader`/`CubeTextureLoader`/HDR loader cần thiết.
- Cache texture theo logical ID.
- Tạo material PBR (`MeshStandardMaterial`) theo recipe; cài đặt `colorSpace`, repeat, anisotropy, normal scale, roughness map.
- Fallback ngay về material procedural màu phù hợp nếu texture báo lỗi hoặc trình duyệt không hỗ trợ.
- Không để texture remote URL tại runtime; mọi URL là đường dẫn `/assets/...` local.

### AudioManager

Module `public/js/audio/audio-manager.js`:

- Khởi tạo `AudioContext` trên click/touch/key đầu tiên; không phát trước đó.
- Duy trì buses: `master`, `ambient`, `ritual`.
- Cảnh `gate` và `courtyard`: tiếng nước/gió/chim + chuông thưa.
- Cảnh `hall`: fade out chim/nước, fade in room tone và layer tụng hợp pháp hoặc drone dự phòng.
- Chuyển cảnh crossfade khoảng 1.2 giây; không tạo audio node trùng khi chuyển lặp lại.
- Có UI bật/tắt, volume 0–100%, mặc định 35%; lưu preference trong `localStorage`.
- Có thể tắt toàn bộ bằng `prefers-reduced-motion` không áp dụng; audio luôn có control rõ ràng.
- Xử lý `visibilitychange`: giảm âm lượng khi tab ẩn, khôi phục có fade khi tab hiện lại.

### Cảnh và builders

- `builders.js` nhận material/asset async hoặc material đã nạp từ registry.
- Các builder hiện hữu vẫn là procedural geometry để giữ phong cách kiến trúc Việt và không phải dùng model không rõ license.
- Tăng chi tiết nhìn gần: variation màu gạch, dirt/moss masks procedural nhẹ, lantern emissive, reflection mặt nước, fog màu ấm/lam theo thời gian cảnh.
- HDR environment map chỉ dùng cho exterior và được dispose khi đổi scene; hall dùng ánh sáng ấm local.

## 5. UI/UX

- Nút âm thanh ở HUD: `🔊 Âm thanh` / `🔇 Tắt âm`; không dùng emoji trong source nếu hệ font không ổn định, thay bằng SVG inline khi triển khai.
- Popup lần đầu vào chùa: “Bật âm thanh không gian?” với **Bật âm thanh** và **Để yên lặng**. Lựa chọn được ghi localStorage; vẫn có thể đổi tại HUD.
- Bảng Attribution ở nút `i` cạnh audio/help. Hiện tên asset, tác giả khi yêu cầu, license và URL.
- Không tự phát nội dung lời tôn giáo bất ngờ; người chơi phải bật âm thanh.

## 6. Dữ liệu và bảo mật

- Không ghi audio setting hoặc asset data lên server, chỉ localStorage.
- Tiến độ chùa/token/session không thay đổi.
- Asset manifest chỉ có thông tin public (tên, license, tác giả, URL, local path, checksum); không có credential hoặc remote API key.
- Docker image tiếp tục read-only. Tất cả static asset được copy trong image; dữ liệu user vẫn tại named volume `/app/data`.

## 7. Regression / rollback

- Nếu GPU yếu/WebGL texture allocation lỗi: AssetRegistry fallback material màu phẳng; game còn chơi được.
- Nếu audio decode/load lỗi: UI báo “Không tải được âm thanh”, game vẫn chạy im lặng; không chặn nhiệm vụ.
- Nếu archive >200 MB: hạ asset 4K xuống 2K theo mức ưu tiên: HDRI → sàn gỗ → mái ngói. Không loại map texture bắt buộc của bề mặt chính.
- Rollback: bỏ registry/audio module và quay về commit `1a8efd6` nếu build/deploy không đạt.

## 8. Acceptance criteria và testcase

| ID | Tiêu chí | Loại test | Bằng chứng |
|---|---|---|---|
| AC-01 | Mái, sân, gỗ, tường, cỏ/đất dùng texture local, không URL runtime bên thứ ba | Unit + browser network | Manifest; request list chỉ `/assets/` |
| AC-02 | Cổng, sân, Bái đường, Chính điện đẹp hơn nhưng luồng nhiệm vụ cũ không đổi | E2E browser | Screenshot + hoàn thành chứng nhận |
| AC-03 | Audio không phát trước click/cử chỉ; sau khi bật phát ambience đúng cảnh | Browser/native audio state | AudioContext state, UI state |
| AC-04 | Tắt audio/volume hoạt động và preference còn sau reload | Browser E2E | localStorage + UI state |
| AC-05 | Chuyển cảnh crossfade; không có nhiều layer duplicate sau 5 lần đổi cảnh | Unit fake audio + E2E | active source/bus count |
| AC-06 | Audio asset dùng lại hợp pháp hoặc fallback được gắn nhãn không lời | Manifest review | `ATTRIBUTION.md` và in-game attribution |
| AC-07 | Texture/audio lỗi vẫn chơi được | Unit/Browser mocked failed URL | fallback materials, warning UI |
| AC-08 | Docker image build và `/healthz` healthy | Docker integration | image build/log/health result |
| AC-09 | Archive chạy `npm test`, Docker Compose và size ≤ 200 MB | CI/local | test output, archive bytes |
| AC-10 | Tên, auth, progress, certificate và restart persistence không regression | Existing test + E2E | 12+ test pass, journey screenshot |

## 9. Tài liệu tham khảo đã kiểm tra

- Poly Haven Public API / License: https://github.com/Poly-Haven/Public-API
- Roof Tiles: https://polyhaven.com/a/roof_tiles
- Stone Pavers: https://polyhaven.com/a/stone_pavers
- Patterned Cobblestone: https://polyhaven.com/a/patterned_cobblestone
- Stacked Brick Wall: https://polyhaven.com/a/stacked_brick_wall
- Rosewood Veneer 02: https://polyhaven.com/a/rosewood_veneer_02
- Plank Flooring: https://polyhaven.com/a/plank_flooring
- Grass Ground: https://polyhaven.com/a/grass_ground
- Large Pebbles: https://polyhaven.com/a/large_pebbles
- Video tham khảo layout, không lấy media vào game: https://www.youtube.com/watch?v=4VhYTP0doxc
