# Chùa Trấn Quốc Asset & Audio Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the flat temple scene materials with high-quality, locally bundled licensed PBR assets and add opt-in spatially layered sound across the Trấn Quốc visit.

**Architecture:** `AssetRegistry` owns all texture load/caching, material recipes, local fallback assets, and attribution metadata. `AudioManager` owns user-gesture activation, zone mix targets, crossfades, volume persistence, and graceful decode/network failure behavior. Existing procedural architecture remains geometry-driven; builders accept material recipes from the registry so no unlicensed third-party models are required.

**Tech Stack:** Node.js 22, Express 5, Three.js, Web Audio API, Docker Compose, Poly Haven CC0 PBR textures, Wikimedia Commons CC BY-SA chant only if license page and source bytes are independently verified.

**Spec:** `docs/superpowers/specs/2026-11-01-tran-quoc-assets-and-audio-design.md`

## Global Constraints

- Bundle only local assets with verified CC0/CC BY/CC BY-SA redistribution rights; never use downloaded YouTube, stock, or unclear-license media.
- Store author, source URL, license, local file, and SHA-256 for every bundled external asset in `public/assets/ATTRIBUTION.md` and `public/assets/manifest.json`.
- Target 2K PBR maps by default; use 4K only on roof/sanctuary floor; archive size must be ≤200 MB.
- No remote runtime asset URL; network requests after initial page load must be same-origin `/assets/` only.
- Audio starts only after explicit gesture; default volume 35%; show enabled/muted control and save preference in localStorage.
- Audio failure, WebGL texture failure, or low GPU must not block character creation, travel, tasks, incense, or certification.
- Docker remains non-root/read-only; static assets ship inside image and user data remains in `/app/data` named volume.

## Review Focus

- Corrupt/unavailable texture or audio byte: assert material/audio fallback and no rejected game flow.
- Browser rejects Web Audio before a user gesture: assert no context/source starts before `enable()`.
- Re-entering gate/courtyard/hall repeatedly: assert active audio layer count remains bounded and crossfade does not duplicate sources.
- 4K assets on constrained WebGL: assert quality tier falls back to 2K/procedural without an uncaught WebGL error.
- CC BY-SA attribution visibility: assert source/license links remain available from HUD attribution dialog and in archive manifest.

---

## File Structure

| File | Responsibility |
|---|---|
| `public/assets/manifest.json` | Logical local asset paths, quality tiers, checksums and license metadata. |
| `public/assets/ATTRIBUTION.md` | Human-readable attribution/license record. |
| `public/assets/textures/*` | Verified downloadable PBR texture maps and HDR environment. |
| `public/assets/audio/*` | Verified external audio only; generated non-verbal fallback loop is separately flagged. |
| `public/js/assets/registry.js` | Load/cache local textures/HDR; make PBR material recipes and safe fallback materials. |
| `public/js/audio/audio-manager.js` | Gesture-gated audio graph, scene layer crossfades, controls/preferences, fallbacks. |
| `public/js/temple/builders.js` | Receive material palette/recipes in place of hard-coded flat materials. |
| `public/js/temple/tranquoc.js` | Create async scenes with registry material palette and call scene audio profile. |
| `public/js/temple/engine.js` | Hold registry lifecycle, emit scene activation hooks, dispose GPU assets safely. |
| `public/js/temple/visit.js` | Own AudioManager, audio permission UI, HUD controls, attribution modal, scene audio transitions. |
| `public/style.css` | Sound permission/volume/attribution HUD styling. |
| `test/assets.test.js` | Manifest and local asset validation. |
| `test/audio.test.js` | Fake AudioContext lifecycle, crossfade and preference tests. |
| `test/temple-assets.test.js` | Asset registry fallback/material recipe tests. |

### Task 1: Acquire and document licensed assets

**Files:**
- Create: `public/assets/manifest.json`
- Create: `public/assets/ATTRIBUTION.md`
- Create: `public/assets/textures/*`
- Create: `public/assets/audio/*`
- Create: `test/assets.test.js`

**Interfaces:**
- Produces: `AssetManifest` entries `{ id, kind, localPath, license, sourceUrl, sha256, tier? }`.
- Consumes: nothing.

- [ ] **Step 1: Write failing manifest-validation tests**

```js
test('every manifest asset has a local file, SHA-256, source URL, and approved license', () => {
  for (const asset of manifest.assets) {
    assert.ok(fs.existsSync(publicPath(asset.localPath)));
    assert.match(asset.sha256, /^[a-f0-9]{64}$/);
    assert.ok(['CC0-1.0', 'CC-BY-4.0', 'CC-BY-SA-4.0', 'GENERATED'].includes(asset.license));
  }
});

test('archive asset payload is at most 200 MB', () => {
  assert.ok(totalBytes(manifest.assets) <= 200 * 1024 * 1024);
});
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `node --test test/assets.test.js`  
Expected: FAIL because manifest/assets do not exist.

- [ ] **Step 3: Download and package verified assets**

Use Poly Haven file API with local SHA-256 verification for roof tiles, stone pavers/patterned cobblestone, brick, rosewood/plank flooring, grass/pebbles and an HDRI. Use 2K recipes; promote roof and hall floor to 4K only if the verified aggregate remains under 200 MB.

For chant audio, inspect the source page plus actual file metadata/license. Bundle only a CC0/CC BY/CC BY-SA recording that permits reuse; otherwise generate a non-verbal drone/temple-bell fallback and mark it `GENERATED` rather than calling it chanting.

- [ ] **Step 4: Write `manifest.json` and `ATTRIBUTION.md`**

Every external file includes exact source URL, creator if provided, exact license, SHA-256 and use in game. Include a plain statement when no verified Vietnamese chanting source was found.

- [ ] **Step 5: Run asset tests**

Run: `node --test test/assets.test.js`  
Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add public/assets test/assets.test.js
git commit -m "assets: add licensed temple texture and audio bundle"
```

### Task 2: Add safe texture registry and PBR material recipes

**Files:**
- Create: `public/js/assets/registry.js`
- Modify: `public/js/temple/builders.js`
- Test: `test/temple-assets.test.js`

**Interfaces:**
- Consumes: `public/assets/manifest.json` from Task 1.
- Produces: `AssetRegistry.load(): Promise<void>`, `AssetRegistry.material(recipe, options): THREE.Material`, `AssetRegistry.dispose(): void`, `AssetRegistry.usingFallback(id): boolean`.

- [ ] **Step 1: Write failing registry tests**

```js
test('material recipe loads local albedo, normal and roughness maps with correct color space', async () => {
  const registry = registryWithSuccessfulLoaders();
  await registry.load();
  const material = registry.material('roof');
  assert.equal(material.map.colorSpace, THREE.SRGBColorSpace);
  assert.ok(material.normalMap);
  assert.ok(material.roughnessMap);
});

test('failed texture resolves to a safe procedural fallback material', async () => {
  const registry = registryWithFailingTexture('roof');
  await registry.load();
  assert.equal(registry.usingFallback('roof'), true);
  assert.equal(registry.material('roof').map, null);
});
```

- [ ] **Step 2: Run tests to verify failure**

Run: `node --test test/temple-assets.test.js`  
Expected: FAIL because `AssetRegistry` is missing.

- [ ] **Step 3: Implement `AssetRegistry`**

Use same-origin URL construction from the manifest only. Configure repeat wrapping, anisotropy capped by renderer capability, color-space assignment, normal-scale, and texture disposal. Provide named recipes: `roof`, `paving`, `brick`, `rosewood`, `hallFloor`, `grass`, `stone`, `bronze`.

- [ ] **Step 4: Refactor builder material boundary**

Change builders to accept `{ materials }` or registry material getters. Retain existing procedural geometry and default colors for registry failures; avoid unrelated geometry refactoring.

- [ ] **Step 5: Run registry and existing tests**

Run: `node --test test/temple-assets.test.js test/temple.test.js`  
Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add public/js/assets/registry.js public/js/temple/builders.js test/temple-assets.test.js
git commit -m "feat: add PBR asset registry for temple scenes"
```

### Task 3: Apply PBR materials, environment and quality tiers to scenes

**Files:**
- Modify: `public/js/temple/engine.js`
- Modify: `public/js/temple/tranquoc.js`
- Modify: `public/js/temple/builders.js`
- Test: `test/temple-assets.test.js`

**Interfaces:**
- Consumes: `AssetRegistry` from Task 2.
- Produces: `Engine({ assetRegistry })`; each scene builder awaits/uses registry recipes and calls `setEnvironment(sceneProfile)`.

- [ ] **Step 1: Add failing scene-palette/quality tests**

```js
test('courtyard routes roof, paving, brick, grass and wood through registry recipes', async () => {
  const names = await recordedSceneRecipeNames(courtyardScene);
  assert.deepEqual(new Set(names), new Set(['roof', 'paving', 'brick', 'grass', 'rosewood', 'stone']));
});

test('low quality tier does not request 4K materials', async () => {
  const registry = registryForTier('low');
  await registry.load();
  assert.equal(registry.requestedTier('roof'), '2k');
});
```

- [ ] **Step 2: Run tests to verify failure**

Run: `node --test test/temple-assets.test.js`  
Expected: FAIL because scenes still instantiate flat materials.

- [ ] **Step 3: Implement scene material routing**

Make scene construction asynchronous where required. Apply roof, paving, brick, wood, grass/ground and stone PBR recipes; use controlled UV repeat per geometry size. Add local HDR environment only to exterior, warm indoor environment/light to hall, and explicit renderer resource disposal on scene replacement.

- [ ] **Step 4: Add quality selection**

Choose high tier when renderer capability and viewport permit, else 2K; expose no manual developer-only UI. On texture allocation failure, retry the affected recipe at 2K/fallback.

- [ ] **Step 5: Run tests**

Run: `node --test test/assets.test.js test/temple-assets.test.js test/temple.test.js`  
Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add public/js/temple/engine.js public/js/temple/tranquoc.js public/js/temple/builders.js test/temple-assets.test.js
git commit -m "feat: render Trấn Quốc scenes with PBR temple materials"
```

### Task 4: Implement gesture-gated scene audio manager

**Files:**
- Create: `public/js/audio/audio-manager.js`
- Create: `test/audio.test.js`

**Interfaces:**
- Consumes: audio manifest entries from Task 1.
- Produces: `new AudioManager({ manifest, storage, AudioContextCtor })`, `enable(): Promise<boolean>`, `setScene('gate'|'courtyard'|'hall'): Promise<void>`, `setMuted(boolean): void`, `setVolume(0..1): void`, `dispose(): void`, `state`.

- [ ] **Step 1: Write failing fake-AudioContext tests**

```js
test('does not create or start an audio source before enable', () => {
  const audio = makeAudio();
  audio.setScene('courtyard');
  assert.equal(fakeContext.startedSources.length, 0);
});

test('scene transition crossfades bounded layers without duplicates', async () => {
  const audio = await enabledAudio();
  await audio.setScene('courtyard');
  await audio.setScene('hall');
  assert.equal(audio.activeLayerIds().filter(id => id === 'hall-drone').length, 1);
  assert.ok(fakeContext.gainAutomation.some(a => a.type === 'linearRamp'));
});

test('mute/volume survives reconstruction from storage', async () => {
  const storage = fakeStorage({ 'di-chua.audio.volume': '0.35', 'di-chua.audio.muted': 'true' });
  const audio = makeAudio({ storage });
  assert.equal(audio.volume, 0.35);
  assert.equal(audio.muted, true);
});

test('decode/network failure leaves gameplay audio disabled without throw', async () => {
  const audio = makeAudio({ fetch: failingFetch });
  assert.equal(await audio.enable(), false);
  assert.equal(audio.state, 'failed');
});
```

- [ ] **Step 2: Run tests to verify failure**

Run: `node --test test/audio.test.js`  
Expected: FAIL because `AudioManager` is missing.

- [ ] **Step 3: Implement `AudioManager`**

Use a master gain and child ambient/ritual gains. Scene profiles: gate/courtyard combine nature and sparse bell; hall combines indoor room tone and verified chant or labeled non-verbal fallback. Use 1.2s linear/cosine fade, stop stale nodes after fade, catch fetch/decode errors, and never retry indefinitely.

- [ ] **Step 4: Run audio tests**

Run: `node --test test/audio.test.js`  
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add public/js/audio/audio-manager.js test/audio.test.js
git commit -m "feat: add opt-in temple ambience audio manager"
```

### Task 5: Integrate audio controls, attribution and scene activation UI

**Files:**
- Modify: `public/js/temple/visit.js`
- Modify: `public/js/temple/engine.js`
- Modify: `public/style.css`
- Test: `test/audio.test.js`

**Interfaces:**
- Consumes: `AudioManager` from Task 4 and `AssetRegistry` from Task 2.
- Produces: HUD audio toggle/volume/attribution dialog; first-gesture consent; `TempleVisit.goScene()` sets audio profile.

- [ ] **Step 1: Add failing integration behavior tests**

```js
test('first explicit enable interaction activates audio and scene profile', async () => {
  const visit = mountedVisit();
  await click(visit, 'enable-audio');
  assert.equal(visit.audio.state, 'enabled');
  assert.equal(visit.audio.currentScene, 'gate');
});

test('skip keeps game playable and no audio is started', async () => {
  const visit = mountedVisit();
  await click(visit, 'keep-silent');
  assert.equal(visit.audio.state, 'silent');
  assert.equal(fakeContext.startedSources.length, 0);
});
```

- [ ] **Step 2: Run test to verify failure**

Run: `node --test test/audio.test.js`  
Expected: FAIL because visit HUD controls do not exist.

- [ ] **Step 3: Implement consent and HUD controls**

Add first-visit sound prompt with “Bật âm thanh”/“Để yên lặng”, accessible labels, mute toggle, range slider, attribution dialog, and failure notice. `goScene()` requests a profile only after sound is enabled. Add visibility-change attenuation/restoration.

- [ ] **Step 4: Run UI/audio tests**

Run: `node --test test/audio.test.js`  
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add public/js/temple/visit.js public/js/temple/engine.js public/style.css test/audio.test.js
git commit -m "feat: add temple sound controls and attribution UI"
```

### Task 6: End-to-end verification, container build and distributable archive

**Files:**
- Modify: `Dockerfile` only if asset paths require an explicit copy adjustment.
- Modify: `compose.yaml` only if a resource/read-only requirement needs correction.
- Modify: `test/*` only to add missing regression coverage found during verification.

**Interfaces:**
- Consumes: completed Tasks 1–5.
- Produces: verified local source, Docker image and archive ≤200 MB.

- [ ] **Step 1: Run baseline automated tests and syntax checks**

Run: `npm test && node --check public/js/assets/registry.js && node --check public/js/audio/audio-manager.js`  
Expected: all tests PASS and no syntax output.

- [ ] **Step 2: Run browser E2E**

Use a fresh account: create character → open Trấn Quốc → reject and accept audio in separate runs → read history → accept NPC quest → visit zones → complete incense ritual → receive certificate. Verify local `/assets/` request paths, audio control persistence across reload, fallback interception behavior and no console error.

- [ ] **Step 3: Build Docker image and check health**

Run: `docker compose build --no-cache && docker compose up -d && docker compose ps && curl -fsS http://localhost:3000/healthz`  
Expected: service is healthy and health endpoint returns `{ "ok": true }`.

- [ ] **Step 4: Check archive, license data and image size**

Create ZIP/TAR.GZ omitting `node_modules`, `data`, `.git`; run `sha256sum -c SHA256SUMS.txt`; assert archive ≤200 MB; inspect it includes Docker config, assets and attribution but excludes test account data.

- [ ] **Step 5: Commit verification adjustments**

```bash
git add Dockerfile compose.yaml test public/assets
git commit -m "test: verify temple asset and audio delivery"
```

### Task 7: Publish the verified source archive

**Files:**
- Modify: public UI preview repository `ui-preview/di-chua-viet-nam/*` only after Task 6 passes.

**Interfaces:**
- Consumes: Task 6 verified ZIP/TAR.GZ and SHA256SUMS.
- Produces: public download page link at `view.hangocthanh.io.vn`.

- [ ] **Step 1: Replace archives, checksums, and version notes in public preview**

Place archives plus updated `SHA256SUMS.txt` into `ui-preview/di-chua-viet-nam/`; mention quality asset bundle and opt-in ambience license policy.

- [ ] **Step 2: Commit, push branch, merge approved PR and dispatch `deploy-preview-memory-caddy.yml`**

Verify branch/base/commit, then monitor the exact workflow run to success.

- [ ] **Step 3: Verify public links with browser and HTTP**

Open the download page in Playwright, assert three links visible, download endpoints return 200, and report the immutable preview URL plus SHA-256.

- [ ] **Step 4: Commit any publish-only correction**

```bash
git add ui-preview/di-chua-viet-nam
git commit -m "docs: publish enhanced Đi chùa Việt Nam bundle"
```

## Self-review

- **Spec coverage:** Tasks 1–7 cover licensing/attribution, quality ceiling, material registry, visuals, audio behaviors, fallbacks, Docker/archive, and public release.
- **Type consistency:** `AssetRegistry` is produced in Task 2 and consumed in Tasks 3/5; `AudioManager` is produced in Task 4 and consumed in Task 5; named scene IDs are consistent with existing `gate`, `courtyard`, and `hall` scenes.
- **Review focus:** texture/audio failures, browser gesture enforcement, duplicated layers, weak GPU and attribution are each owned by Tasks 2/4/5/6.
- **Scope:** Audio and visual subsystems have separate tasks but share only registry/scene integration; they remain within one cohesive enhancement release.
- **No placeholders:** Asset IDs may be substituted only when Poly Haven API lookup proves an exact ID unavailable; the replacement must remain in manifest/attribution and preserve the stated material role.
